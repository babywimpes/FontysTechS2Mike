#ifndef STRINGYTIFY_H
#define STRINGYTIFY_H
#include <stdlib.h>

#define MaxSize 100

typedef struct{
    int len;
    char str[MaxSize];

}Stringitify;
int InitializeString(char* stri, Stringitify* str);

int StringLength(Stringitify* this);

int StringInsert(Stringitify* str, size_t index, char* insert);

int SearchForSubstring(Stringitify* str, char* replaceWhat);


int StringReplaceInBiggerSize(Stringitify* str, char* replaceWith, int loc, int replaceWithLen, int replaceWhatLen);

int StringReplaceInSmallerSize(Stringitify* str, char* replaceWith, int loc, int replaceWithLen, int replaceWhatLen);

int StringReplace(Stringitify* str, char* replace, char* replaceWith);

char CharAt(Stringitify* str, size_t index);

#endif