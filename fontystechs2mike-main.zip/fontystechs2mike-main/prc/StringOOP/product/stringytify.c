#include "stringytify.h"
#include <string.h>
#include <stdio.h>
int InitializeString(char* stri, Stringitify* str){
   if(str == NULL || stri == NULL){
        return -1;
    }
    int size = strlen(stri);
    if(size + 1 > MaxSize ){
        return -1;
    }
    str->len = size + 1;
    strcpy(str->str, stri);
    return 0;
}

int StringLength(Stringitify* str){
    if(str == NULL){
        return -1;
    }
    return str->len;
}

int StringInsert(Stringitify* str, size_t index, char* insert){
    if(str == NULL || insert == NULL ){
        return -1;
    }

    int insertlen = strlen(insert) ;
    if( str->len + insertlen > MaxSize || index > str->len ){
        return -1;
    }
    for (int i = 0; i < str->len + 1 - index; i++) {
        str->str[str->len - i + insertlen] = str->str[str->len - i];
    }
    strncpy(str->str + index, insert, insertlen);
    str->len += insertlen;
    
    return 0;
}

int SearchForSubstring(Stringitify* str, char* replaceWhat)
{
    if(str == NULL || replaceWhat == NULL){
        return -1;
    }

    int i = 0;
    int j = 0;
    int loc = 0;
    while(str->str[i] != '\0'){
        if(str->str[i] == replaceWhat[j]){
            if(j == 0){
                loc = i;
            }
            j++; 
        }
        else{
            j = 0;
        }
        i++;
        if(replaceWhat[j]=='\0'){
            return loc;
        }
    }

    if(loc == 0){
        return -1;
    }
    return loc;  
}

int StringReplaceInBiggerSize(Stringitify* str, char* replaceWith, int loc, int replaceWithLen, int replaceWhatLen)
{
    if(str == NULL || replaceWithLen < 0 || replaceWhatLen < 0){
        return -1;
    }
    int diff = str->len - loc;
    for (int k = 0; k < diff; k++) {
        str->str[loc + replaceWithLen + k] = str->str[loc + replaceWhatLen + k];
    }
    for(int k = 0; k < replaceWithLen; k++){
        str->str[loc + k] = replaceWith[k];
    }
    str->len = str->len + replaceWithLen - replaceWhatLen;
    return 0;
}

int StringReplaceInSmallerSize(Stringitify* str, char* replaceWith, int loc, int replaceWithLen, int replaceWhatLen)
{
    if(str == NULL || replaceWith == NULL){
        return -1;
    }
    int diff = replaceWithLen - replaceWhatLen;
    for(int k = str->len; k > loc ; k--){
        str->str[k + diff] = str->str[k];
    }
    for(int k = loc; k < loc + replaceWithLen; k++){
        str->str[k] = replaceWith[k - loc];
    }
    return 0;
}

int StringReplace(Stringitify* str, char* replaceWhat, char* replaceWith)
{
    if(str == NULL || replaceWhat == NULL || replaceWith == NULL ){
        return -1;
    } 

    int replaceWithLen = strlen(replaceWith);
    int replaceWhatLen = strlen(replaceWhat);
    int loc = SearchForSubstring(str, replaceWhat);
    if (str->len + (replaceWithLen - replaceWhatLen) > MaxSize || loc == -1){
        return -1;
    }

    if(replaceWhatLen > replaceWithLen){
        StringReplaceInBiggerSize(str, replaceWith, loc, replaceWithLen, replaceWhatLen);
    }
    else if(replaceWhatLen < replaceWithLen){
        StringReplaceInSmallerSize(str, replaceWith, loc, replaceWithLen, replaceWhatLen);
    }
    else{
        for(int k = 0; k < replaceWithLen; k++){
            str->str[loc + k] = replaceWith[k];
        }
    }
    
    str->len = str->len + replaceWithLen - replaceWhatLen;
    return 0;
}


char CharAt(Stringitify* str, size_t index){
    if(str == NULL || index-1 > str->len){
        return '\0';
    }
    return str->str[index-1];
}