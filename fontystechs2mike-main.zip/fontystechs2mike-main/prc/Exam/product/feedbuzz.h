#ifndef FEEDBUZZ_H
#define FEEDBUZZ_H

#define NUMBER 30
#define FEED "FEED"
#define BUZZ "BUZZ"

void FeedBuzz();

#endif