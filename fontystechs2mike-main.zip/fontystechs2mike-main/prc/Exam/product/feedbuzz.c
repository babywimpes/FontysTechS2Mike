#include "feedbuzz.h"
#include <stdio.h>

void FeedBuzz(){
    for(int i = 1; i<=NUMBER; i++){
        if((i % 5) + (i % 3) == 0){
            printf("%i | %s%s \n",   i,FEED, BUZZ);
        }
        else if((i % 3) == 0){
            printf("%i | %s \n",   i, FEED);
           
        }
        else if((i % 5) == 0){
            printf("%i | %s \n",   i, BUZZ);
        }

        else{
            printf("%i | \n", i);
        }

    }
}