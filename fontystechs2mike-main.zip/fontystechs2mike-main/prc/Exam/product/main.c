#include <stdio.h>

#include "feedbuzz.h"

int main()
{
    //delen door 3 is feed
    //delen doo r5 is buzz
    //delen door bijde is feedbuzz

    // n < 15, N = variabel

    
    printf("FeedBuzz\n");

    FeedBuzz();


    return 0;
}
