#include <stdio.h>
#include <stdbool.h>

int numbers[] = {2,3,5,1,7,8,6,4,120,23,4,12,5,24,654,1};

size_t n = sizeof(numbers)/sizeof(numbers[0]);

int main()
{   
    bool is_swapped= true;  
    while (is_swapped)
    {
        is_swapped = false;
        for (int j = 0; j < n-1; j++)
        {
            if(numbers[j]<numbers[j+1]){
                int temp = numbers[j];
                numbers[j] = numbers[j+1];
                numbers[j+1] = temp;
                is_swapped = true;
                printf("swapped %d and %d \n", numbers[j], numbers[j+1]);
            } 
        }        
    }
    for(int b = 0; b < n; b++){
            printf(" %i \n", numbers[b]);
    }  
    return 0;
}