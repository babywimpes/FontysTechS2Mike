#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#define SIZE 10

void RingbufferInit();
int RingbufferGetNrValues();
int RingbufferRead(int* data);
void RingbufferWrite(int data);
int RingbufferGetAverage(int* average);

#endif
