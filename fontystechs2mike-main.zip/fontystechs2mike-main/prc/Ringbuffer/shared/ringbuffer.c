#include "ringbuffer.h"
#include <stdio.h>

static int n = 0;
static int array[SIZE];
static int* arrayWrite = array;
static int* arrayRead = array;

void RingbufferInit(){
    for(int i = 0; i<SIZE; i++){
        array[i]= 0;
    }
    arrayWrite = array;
    arrayRead = array;
    n=0;
}

int RingbufferGetNrValues(){
    return n;
}

int RingbufferRead(int* data){
    if(data == NULL){
        return -1;
    }
    if(n > 0){
        *data = *(arrayWrite-1);
        n--;
        return 1;
    }   
    return 0;
}

void RingbufferWrite(int data){
   
    if(arrayWrite > array + SIZE-1){
        arrayWrite = array;
    }
    if(arrayWrite == arrayRead){
        arrayRead++;
        if(arrayRead > array + SIZE-1){
            arrayRead = array;
        }
    }
    *arrayWrite = data;
    arrayWrite++;
    n++;
}

int RingbufferGetAverage(int *average){
    if(n != SIZE && average ==NULL){
        return -1;
    }

    int temp=0;
    for(int i = 0; i<SIZE; i++){
        temp+= array[i];
    }
    temp /=SIZE;
    *average = temp; 
    return 0;
}