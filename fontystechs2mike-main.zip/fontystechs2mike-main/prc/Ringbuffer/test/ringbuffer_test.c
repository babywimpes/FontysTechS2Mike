#include "ringbuffer.h"
#include "unity.h"
#include "unity_test_module.h"

#include <string.h> /* for memcmp */

// I rather dislike keeping line bigints updated, so I made my own
// macro to ditch the line bigint
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

void ringbuffer_setUp()
{
    // This is run before EACH test
    RingbufferInit();
}

void ringbuffer_tearDown()
{
    // This is run after EACH test
}

static void test_RingbufferGetNrValues_after_init()
{
    TEST_ASSERT_EQUAL(0, RingbufferGetNrValues());
}

static void test_RingBufferRead_after_init(){
    int outdata = 81690;
    TEST_ASSERT_EQUAL(0, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(81690, outdata);
}

static void test_RingBufferGetAverage_after_init(){
    int outdata = 0; 
    TEST_ASSERT_EQUAL(0, RingbufferGetAverage(&outdata));
    TEST_ASSERT_EQUAL(0, outdata);
}

static void test_RingBufferWrite_after_init(){
    int indata1 = 100;
    int indata2 = 69;
    int indata3 = 34; 
    int indata4 = 20;
    int indata5 = 14;
    int outdata = 786;
    RingbufferWrite(indata1);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata1, outdata);

    RingbufferWrite(indata2);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata2, outdata);

    RingbufferWrite(indata3);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata3, outdata);

    RingbufferWrite(indata4);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata4, outdata);

     RingbufferWrite(indata5);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata5, outdata);
    
    TEST_ASSERT_EQUAL(0, RingbufferGetNrValues());
}

static void test_RingBufferWrite_overflow(){
    int indata1 = 9874;
    int indata2 = 31245;
    int outdata = 13154;
    for(int i = 0; i<SIZE; i++){
        RingbufferWrite(indata1);
    }
    RingbufferWrite(indata2);
    
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata2, outdata);
    RingbufferWrite(indata2);
    TEST_ASSERT_EQUAL(1, RingbufferRead(&outdata));
    TEST_ASSERT_EQUAL(indata2, outdata);

    RingbufferInit();

}


static void test_RingBufferAverage(){
    int indata1 = 5;
    int outdata = 53;
    for(int i = 0; i<SIZE; i++){
        RingbufferWrite(indata1);
    }
    TEST_ASSERT_EQUAL(0, RingbufferGetAverage(&outdata));
    TEST_ASSERT_EQUAL(5, outdata);
}

void run_ringbuffer_tests()
{
    UnityRegisterSetupTearDown( ringbuffer_setUp, ringbuffer_tearDown);
    printf("\nTESTS: %s\n", __FUNCTION__);

    MY_RUN_TEST(test_RingbufferGetNrValues_after_init);
    MY_RUN_TEST(test_RingBufferRead_after_init);
    MY_RUN_TEST(test_RingBufferGetAverage_after_init);
    MY_RUN_TEST(test_RingBufferWrite_after_init);
    MY_RUN_TEST(test_RingBufferWrite_overflow);
    MY_RUN_TEST(test_RingBufferAverage);
    UnityUnregisterSetupTearDown();
}
