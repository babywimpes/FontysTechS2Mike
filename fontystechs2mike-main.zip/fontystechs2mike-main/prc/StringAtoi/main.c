#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>


#define MAX_LENGTH 100


int arrayman[1];

bool IsDigit(char* character)
{
    if(*character >= '0' && *character <= '9'){
        return true;
    }
    return false;
}

 
int main () {
    size_t size = 0;
    char hoi[MAX_LENGTH]= "Hell4oa World3" ;
    int a = strlen(hoi);
    int num_index = 0;

    for(int i = 0; i < a ; i++)
    {
        if(IsDigit(&hoi[i]))
        {
            //resize array if needed 
            if(num_index >= size)
            {
                size = size * 2;
                arrayman = realloc(arrayman, size * sizeof(int));
            }
        }
    }
    for(int j = 0; j < sizeof(arrayman) / sizeof(int); j++)
    {
        printf("%d", arrayman[j]);
    }

   

   return(0);
}