/*
 * stegano.c
 *
 *  Created on: Nov 6, 2011
 *      Author: J. Geurts
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bmp.h"
#include "resource_detector.h"
#include "stegano.h"

#define MAX_FILENAME 80

extern uint8_t SteganoGetSubstring(
    uint8_t Src, uint8_t SrcPos, uint8_t NrOfBits, uint8_t DestPos)
/* description: get a substring of bits from a uint8_t (i.e. a byte)
 *
 * example: SteganoGetSubstring (Src, 3, 4, 1) with Src=ABCDEFGH (bit H is LSB)
 *          = 000BCDE0
 *
 * parameters:
 *      Src:       byte to get the substring from
 *      SrcPos:    position of the first bit of the substring (LSB=0)
 *      NrOfBits:  length of the substring
 *      DestPos:   position of the first bits of the destination substring
 *
 * return:
 *      substring, starting at DestPos
 */
{
    int mask = (1 << NrOfBits) - 1;
    Src >>= SrcPos;
    Src &= mask;
    Src <<= DestPos;
    return Src;
}

// should be static in real life, but would give a compiling error in the
// unchanged code because this function is not yet used
static void ReadHdr(
    FILE *FilePtr, BMP_MAGIC_t *Magic, BMP_FILE_t *File,
    BMP_INFO_t *Info)
/*
 * description: read the header of a bmp File, and store the data in the
 * provided parameters
 *
 * parameters:
 *         FilePtr: file, opened for reading
 *         Magic:   output-parameter to store the read BMP_MAGIC_t structure
 *         File:    output-parameter to store the read BMP_FILE_t structure
 *         Info:    output-parameter to store the read BMP_INFO_t structure
 *
 * Note: caller should provide enough memory for parameters 'Magic', 'File' and
 * 'Info'
 */
{
    fread(Magic, sizeof(*Magic), 1, FilePtr);
    fread(File, sizeof(*File), 1, FilePtr);
    fread(Info, sizeof(*Info), 1, FilePtr);
}

// should be static in real life, but would give a compiling error in the
// unchanged code because this function is not yet used
static void WriteHdr(
    FILE *FilePtr, BMP_MAGIC_t *Magic, BMP_FILE_t *File,
    BMP_INFO_t *Info)
/*
 * description: write the header of a bmp File, where the data comes from the
 * provided parameters
 *
 * parameters:
 *         FilePtr: file, opened for writing
 *         Magic:   input-parameter with a BMP_MAGIC_t structure
 *         File:    input-parameter with a BMP_FILE_t structure
 *         Info:    input-parameter with a BMP_INFO_t structure
 *
 */
{
    // TODO Write the header to the FilePtr
    fwrite(Magic, sizeof(*Magic), 1, FilePtr);
    fwrite(File, sizeof(*File), 1, FilePtr);
    fwrite(Info, sizeof(*Info), 1, FilePtr);

    // to be implemented
}

void CopyBMP()
{
    char FilePtr[] = "ImageCitroen2Cv.bmp";
    char FilePtr2[] = "new.bmp";
    BMP_MAGIC_t Magic;
    BMP_FILE_t File;
    BMP_INFO_t Info;

    FILE *fp = fopen(FilePtr, "rb");
    FILE *fp2 = fopen(FilePtr2, "wb");
    ReadHdr(fp, &Magic, &File, &Info);
    WriteHdr(fp2, &Magic, &File, &Info);

    fseek(fp, File.bmp_offset, SEEK_SET);
    fseek(fp2, File.bmp_offset, SEEK_SET);

    int bytesPerPixel = Info.bitspp / 8; // delen door 8 omdat de bits per pixel in bytes staan
    int countPixels = Info.width * Info.height * bytesPerPixel;

    printf("%d\n", bytesPerPixel);
    printf("%d\n", countPixels);

    uint8_t pixel;

    for (int i = 0; i < countPixels; i++)
    {
        fread(&pixel, 1, 1, fp);
        fwrite(&pixel, 1, 1, fp2);
    }

    fclose(fp);
    fclose(fp2);
}

extern void SteganoMultiplex(const char *File0, const char *File1)
{
    FILE *FilePtr0 = NULL;
    FILE *FilePtr1 = NULL;
    FILE *FilePtr2 = NULL;
    char buf[MAX_FILENAME];

    for (int NrBits = 0; NrBits <= 8; NrBits++)
    {
        // NrBits: number of bits for the hidden image
        sprintf(buf, "mux_%s_%s_%d.bmp", File0, File1, NrBits);
        FilePtr0 = fopen(File0, "rb");
        FilePtr1 = fopen(File1, "rb");
        FilePtr2 = fopen(buf, "wb");

        BMP_MAGIC_t MagicVisible;
        BMP_FILE_t FileVisible;
        BMP_INFO_t InfoVisible;

        BMP_MAGIC_t MagicHidden;
        BMP_FILE_t FileHidden;
        BMP_INFO_t InfoHidden;

        ReadHdr(FilePtr0, &MagicVisible, &FileVisible, &InfoVisible);
        ReadHdr(FilePtr1, &MagicHidden, &FileHidden, &InfoHidden);
        FileVisible.creator1 = InfoHidden.width;
        FileVisible.creator2 = InfoHidden.height;
        InfoVisible.nimpcolors = NrBits;

        WriteHdr(FilePtr2, &MagicVisible, &FileVisible, &InfoVisible);
        fseek(FilePtr0, FileVisible.bmp_offset, SEEK_SET);
        fseek(FilePtr1, FileHidden.bmp_offset, SEEK_SET);

        int bytesPerPixel = InfoVisible.bitspp / 8; // delen door 8 omdat de bits per pixel in bytes staan
        int countPixels = InfoVisible.width * InfoVisible.height * bytesPerPixel;

        uint8_t pixel;
        uint8_t pixel2;
        for (int i = 0; i < countPixels; i++)
        {
            fread(&pixel, 1, 1, FilePtr0);
            pixel = SteganoGetSubstring(pixel, NrBits, 8 - NrBits, NrBits);

            fread(&pixel2, 1, 1, FilePtr1);
            pixel2 = SteganoGetSubstring(pixel2, 8 - NrBits, NrBits, 0);
            pixel |= pixel2;

            fwrite(&pixel, 1, 1, FilePtr2);
        }

        fclose(FilePtr0);
        fclose(FilePtr1);
        fclose(FilePtr2);
    }
}

extern void SteganoMultiplexText(const char *File0, const char *File1)
{
    // int[8] masks = {0x1,}
    FILE *FilePtr0 = NULL;
    FILE *FilePtr1 = NULL;
    FILE *FilePtr2 = NULL;
    char buf[MAX_FILENAME];

    sprintf(buf, "mux_%s_%s.bmp", File0, File1);
    FilePtr0 = fopen(File0, "rb");
    FilePtr1 = fopen(File1, "rb");
    FilePtr2 = fopen(buf, "wb");

    BMP_MAGIC_t MagicVisible;
    BMP_FILE_t FileVisible;
    BMP_INFO_t InfoVisible;

    ReadHdr(FilePtr0, &MagicVisible, &FileVisible, &InfoVisible);

    long countChar = 0;

    // get lenght of text file
    fseek(FilePtr1, 0L, SEEK_END); // seek to end of file
    countChar= ftell(FilePtr1); //place size of fileptr1 in countChar
    fseek(FilePtr1, 0L, SEEK_SET); // seek back to beginning of file
    //end get lenght of text file

    FileVisible.creator1 = countChar;
    WriteHdr(FilePtr2, &MagicVisible, &FileVisible, &InfoVisible);
    
    fseek(FilePtr0, FileVisible.bmp_offset, SEEK_SET);
    fseek(FilePtr2, FileVisible.bmp_offset, SEEK_SET);
    //int bytesPerPixel = InfoVisible.bitspp / 8; // delen door 8 omdat de bits per pixel in bytes staan
    //int countPixels = InfoVisible.width * InfoVisible.height * bytesPerPixel;
   // int countPixels = InfoVisible.bmp_bytesz;

    
    for(int i = 0; i < countChar; i++){
        char c = fgetc(FilePtr1);
       
            for (int j = 0; j <= 7; j++){
                uint8_t mask = 0xFE;
                uint8_t pixel = 0x0;
                uint8_t textbit = 0x0;
                if (fread(&pixel, 1, 1, FilePtr0) != 1)
                {
                    printf("Error reading file\n");
                }
                else
                {    
                    pixel &= mask;       
                    textbit = SteganoGetSubstring(c, 7-j, 1, 0);
                    //printf("%d\n", textbit);
                    pixel |= textbit;
                    fwrite(&pixel, 1, 1, FilePtr2); 
                }
            }
        
    }
    uint8_t tempbuff[InfoVisible.bmp_bytesz - countChar];
    fread(tempbuff, InfoVisible.bmp_bytesz - countChar, 1,  FilePtr0);
    fwrite(tempbuff, InfoVisible.bmp_bytesz - countChar, 1, FilePtr2);

    printf("%ld\n", countChar);
    printf("%d\n", InfoVisible.bmp_bytesz);
    
    fclose(FilePtr0);
    fclose(FilePtr1);
    fclose(FilePtr2);
    }



extern void SteganoDemultiplex(const char *File0, const char *File1, const char *File2)
{
    FILE *FilePtr0 = NULL;
    FILE *FilePtr1 = NULL;
    FILE *FilePtr2 = NULL;

    FilePtr0 = fopen(File0, "rb");
    FilePtr1 = fopen(File1, "wb");
    FilePtr2 = fopen(File2, "wb");

    BMP_MAGIC_t MagicVisible;
    BMP_FILE_t FileVisible;
    BMP_INFO_t InfoVisible;

    ReadHdr(FilePtr0, &MagicVisible, &FileVisible, &InfoVisible);

    int bytesPerPixel = InfoVisible.bitspp / 8; // delen door 8 omdat de bits per pixel in bytes staan
    int countPixels = FileVisible.creator1 * FileVisible.creator2 * bytesPerPixel;
    int NrBits = InfoVisible.nimpcolors; // aantal bits dat de stegano image heeft

    FileVisible.creator1 = 0;
    FileVisible.creator2 = 0;
    InfoVisible.nimpcolors = 0;

    WriteHdr(FilePtr1, &MagicVisible, &FileVisible, &InfoVisible);
    WriteHdr(FilePtr2, &MagicVisible, &FileVisible, &InfoVisible);

    fseek(FilePtr0, FileVisible.bmp_offset, SEEK_SET);
    fseek(FilePtr1, FileVisible.bmp_offset, SEEK_SET);
    fseek(FilePtr2, FileVisible.bmp_offset, SEEK_SET);

    uint8_t pixel;
    for (int i = 0; i < countPixels; i++)
    {
        if (fread(&pixel, 1, 1, FilePtr0) != 1)
        {
            printf("Error reading file\n");
        }
        else
        {
            uint8_t visible = SteganoGetSubstring(pixel, NrBits, 8 - NrBits, NrBits);
            fwrite(&visible, 1, 1, FilePtr1);
            uint8_t hidden = SteganoGetSubstring(pixel, 0, NrBits, 8 - NrBits);
            fwrite(&hidden, 1, 1, FilePtr2);
        }
    }

    fclose(FilePtr0);
    fclose(FilePtr1);
    fclose(FilePtr2);
}

extern void
SteganoDemultiplexText(const char *File0, const char *File1, const char *File2)
{
    FILE *FilePtr0 = NULL;
    FILE *FilePtr1 = NULL;
    FILE *FilePtr2 = NULL;

    FilePtr0 = fopen(File0, "rb"); /* binair lezen */
    FilePtr1 = fopen(File1, "wb"); /* binair schrijven */
    FilePtr2 = fopen(File2, "wb"); /* binair schrijven */

    // to be implemented

    fclose(FilePtr0);
    fclose(FilePtr1);
    fclose(FilePtr2);
}
