#include <stdio.h>  
#include <string.h>

typedef struct {
    int a ;
    //char b[5];
    int b;
} Whatever;

int mystrcmp(char* s1, char* s2){
    if(s1[0] == '\0' || s2[0] == '\0'){
        return -1;
    }
    int i = 0;
    while(s1[i] != '\0' && s2[i] != '\0'){
        printf("%c %c\n", s1[i], s2[i]);
        if(s1[i] != s2[i]){
            return 0;
        }
        i++;
    }
    if(s1[i] == '\0' && s2[i] == '\0'){
        return 1;
    }
}

int Whatevercmp(Whatever* w1, Whatever* w2){
    printf("%d %d\n", w1->b, w2->b);
    return memcmp(w1, w2, sizeof(Whatever));
}

int main(){
    char mystr1[] = "hallo";
    char mystr2[] = "hallo";

    Whatever a = {1, 2};
    Whatever b = {1, 3};

    printf("Vergelijking van str1 en str2 geeft: %i \n", mystrcmp(mystr1, mystr2));

    printf("Vergelijking van struct1 en struct2 geeft: %i \n", Whatevercmp(&a, &b));
    return 0;
    
}

