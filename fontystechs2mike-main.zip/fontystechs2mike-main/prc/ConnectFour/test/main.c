#include "unity_test_module.h"

/* As an alternative for header files we can declare that
 * the following methods are available 'extern'ally.
 */
extern void run_connect_four_tests();

int main(int argc, char* argv[])
{
    UnityTestModule allModules[] =
    {
        { "connect_four", run_connect_four_tests }
    };

    size_t number_of_modules = sizeof(allModules) / sizeof(allModules[0]);

    return UnityTestModuleRun(argc, argv, allModules, number_of_modules);
}
