#include "connect_four.h"
#include "unity.h"
#include "unity_test_module.h"

#include <string.h> /* for memcmp */

// I rather dislike keeping line bigints updated, so I made my own
// macro to ditch the line bigint
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

void connect_four_setUp()
{
    // This is run before EACH test
    init_data();
}

void connect_four_tearDown()
{
    // This is run after EACH test
}

static void test_init_data_correctly_initialises_data()
{
    board_data board[HEIGHT][WIDTH];

    TEST_ASSERT_EQUAL(0, get_board(board, WIDTH, HEIGHT));

    for (int y = 0; y < HEIGHT; y++)
    {
        for (int x = 0; x < WIDTH; x++)
        {
            const int msglen = 50;
            char message[msglen];
            snprintf(message, msglen, "Problem detected at (x, y): (%i, %i)", x, y);

            TEST_ASSERT_EQUAL_MESSAGE(EMPTY, board[y][x], message);
        }
    }
}

static void test_correct_add_player_input(){
    const int column = 2;
    board_data board[HEIGHT][WIDTH];
    get_board(board, WIDTH, HEIGHT);

    add_player_entry(GREEN, column-1);
    for (int y = 0; y < HEIGHT; y++)
    {
        for (int x = 0; x < WIDTH; x++)
        {
            const int msglen = 50;
            char message[msglen];
            snprintf(message, msglen, "Problem detected at (x, y): (%i, %i)", x, y);

            if(x==column-1 && y == HEIGHT){
                TEST_ASSERT_EQUAL_MESSAGE(GREEN, board[y][x], message);
            }
            else{
                TEST_ASSERT_EQUAL_MESSAGE(EMPTY, board[y][x], message);
            }
        }
    }
}

static void test_wrong_add_player_input(){
    const int column = 9;
    board_data board[HEIGHT][WIDTH];
    get_board(board, WIDTH, HEIGHT);

    TEST_ASSERT_EQUAL_INT(-1, add_player_entry(GREEN, column-1));
    
}

void run_connect_four_tests()
{
    UnityRegisterSetupTearDown( connect_four_setUp, connect_four_tearDown);
    printf("\nTESTS: %s\n", __FUNCTION__);

    MY_RUN_TEST(test_init_data_correctly_initialises_data);
    MY_RUN_TEST(test_correct_add_player_input);
    MY_RUN_TEST(test_wrong_add_player_input);
    
    UnityUnregisterSetupTearDown();
}
