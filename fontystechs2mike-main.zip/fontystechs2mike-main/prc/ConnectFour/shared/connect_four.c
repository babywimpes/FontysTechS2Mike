#include "connect_four.h"

#include <stdio.h>
#include <string.h>

static board_data board[HEIGHT][WIDTH];


// Initialises board data (sets all fields to EMPTY),
// needs to be called before a game can start
void init_data()
{
    for(int y = 0; y <HEIGHT; y++){
        for(int x = 0; x < WIDTH; x++){
           board[y][x] = EMPTY;
        }    
    }
}

// Reads the board data, so the UI can print it.
// user_board: output array, should have exactly WIDTH columns
//             and at least HEIGHT rows
// width: nr of columns in the user_board array
// height: nr of rows in the user_board array
// returns: -1 in case of an error, else 0
int get_board(board_data user_board[][WIDTH], int width, int height)
{
    if(WIDTH != width){
        return -1;
    }
    if(HEIGHT<height){
        return -1;
    }
    for(int y = 0; y <height; y++){
        for(int x = 0; x < width; x++){
            user_board[y][x] = board[y][x];
        }    
    }
    return 0;
}

// Adds an entry for a player
// player: the player who entered a value, is not
//         allowed to be EMPTY
// column: the column that was chosen by player, where
//         1 <= column <= WIDTH
// returns: -1 in case of an error, else 0
int add_player_entry(board_data player, int column)
{
    if(player != EMPTY)
    {
        if(  column > WIDTH || column < 1){
            return -1;
        }   
        else{
            for(int y = HEIGHT-1; y>=0; y--){
                if(board[y][column-1] == EMPTY){
                   board[y][column-1] = player;
                   return 0;
                }
            }
        }
    }  
    return -1;
}

// Checks if a player has won, if it is a draw or ifW
// the game is not yet finished.
// returns:
// - NOT_FINISHED: board is not yet full, nobody won yet
// - RED_WON: red has NR_IN_ROW connected entrys
// - GREEN_WON: green has NR_IN_ROW connected entrys
// - DRAW: nobody has won but the board is full
game_status check_four_connected()
{ 
    //horizontal check
    for(int y = HEIGHT-1; y>=0; y--){
        
    int check4= 0;
        for(int x = 0; x<HEIGHT; x++){
            if(board[y][x+1] == board[y][x]){
                
               

            }
        }       
    }
    //if(check4 ==4){
        
        //return _WON;
    //}
    return NOT_FINISHED;
}
