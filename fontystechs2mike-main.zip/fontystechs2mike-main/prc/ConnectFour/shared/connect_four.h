#ifndef CONNECT_FOUR_H
#define CONNECT_FOUR_H

#define WIDTH 7
#define HEIGHT 6
#define NR_IN_ROW 4

#define NR_PLAYERS 2

// board_data must contain (in this order):
// - NR_PLAYERS players
// - a value for an empty field
typedef enum
{
    RED,
    GREEN,
    EMPTY
} board_data;

// game_status must contain (in this order):
// - NR_PLAYERS values for a player that won
// - a value for not finished
// - a value for a draw
typedef enum
{
    RED_WON,
    GREEN_WON,
    NOT_FINISHED,
    DRAW
} game_status;


// Initialises board data (sets all fields to EMPTY),
// needs to be called before a game can start
void init_data();

// Reads the board data, so the UI can print it.
// user_board: output array, should have exactly WIDTH columns
//             and at least HEIGHT rows
// width: nr of columns in the user_board array
// height: nr of rows in the user_board array
// returns: -1 in case of an error, else 0
int get_board(board_data user_board[][WIDTH], int width, int height);

// Adds an entry for a player
// player: the player who entered a value, is not
//         allowed to be EMPTY
// column: the column that was chosen by player, where
//         1 <= column <= WIDTH
// returns: -1 in case of an error, else 0
int add_player_entry(board_data player, int column);

// Checks if a player has won, if it is a draw or if
// the game is not yet finished.
// returns:
// - NOT_FINISHED: board is not yet full, nobody won yet
// - RED_WON: red has NR_IN_ROW connected entrys
// - GREEN_WON: green has NR_IN_ROW connected entrys
// - DRAW: nobody has won but the board is full
game_status check_four_connected();

#endif
