#include "connect_four.h"

#include <stdio.h>

// ANSI codes for various terminal stuff
#define FONT_BOLD "\033[1;37m"
#define FONT_BOLD_RED "\033[1;31m"
#define FONT_BOLD_GREEN "\033[1;32m"
#define FONT_BOLD_YELLOW "\033[1;33m"
#define FONT_NORMAL "\033[0m"
#define CLEAR_SCREEN "\e[1;1H\e[2J"

// Colour settings for players and empty spot
// used to print correct colour settings for current user,
// something like:
// printf("%s", board_data_coulours[current_user])
static const char board_data_colours[][12] =
{
    FONT_BOLD_RED,
    FONT_BOLD_GREEN,
    FONT_NORMAL
};
// Symbol to print for all players and empty spot
// (\u....: unicode character)
// used in a similar way as board_data_colours
static const char board_data_symbols[][4] =
{
    "\u2584",
    "\u2584",
    "."
};

static const char player_names[NR_PLAYERS][10] =
{
    "Red",
    "Green"
};


// clears terminal screen (only visible part)
static void clear_screen()
{
    printf(CLEAR_SCREEN);
}

// prints a space and the required character, both in given format
static void print_space_char(const char format[], const char text[])
{
    printf("%s %s", format, text);
}

// prints one single board entry
static void print_board_character(board_data data)
{
    print_space_char(board_data_colours[data], board_data_symbols[data]);
}

// prints game information
static void print_game_info()
{
    printf("%sWelcome to Connect %i%s\n", FONT_BOLD, NR_IN_ROW, FONT_NORMAL);
    printf("Your goal is to get %i connected entrys in the board of %i x %i places.\n",
           NR_IN_ROW, WIDTH, HEIGHT);
    printf("The player who first gets to %i connected wins. The game is played\n", NR_IN_ROW);
    printf("with %i players in this order:\n", NR_PLAYERS);
    for (int i = 0; i < NR_PLAYERS; i++)
    {
        printf("    - %s%s%s\n", board_data_colours[i], player_names[i], FONT_NORMAL);
    }
    printf("Good luck!\n");
}

// prints header above the board data
static void print_board_header()
{
    printf("%s\nBoard:\n%s", FONT_NORMAL, FONT_BOLD);
    int nr_chars = 0;
    printf("\t");
    for (int i = 1; i <= WIDTH; i++)
    {
        nr_chars += printf(" %i", i % 10);
    }
    printf("\n\t");
    for (int i = 0; i <= nr_chars; i++)
    {
        printf("=");
    }
    printf("%s\n", FONT_NORMAL);
}

// prints all board data
static void print_board_details()
{
    board_data board[HEIGHT][WIDTH];
    get_board(board, WIDTH, HEIGHT);

    for (int y = 0; y < HEIGHT; y++)
    {
        printf("\t");
        for (int x = 0; x < WIDTH; x++)
        {
            print_board_character(board[y][x]);
        }
        printf("\n");
    }
    printf("\n");
}

// refreshes screen
static void refresh_screen()
{
    clear_screen();
    print_game_info();
    print_board_header();
    print_board_details();
}

// prints game status
static void print_game_status(game_status status)
{
    if (status == NOT_FINISHED)
    {
        printf("\n%sERROR:%s nobody has won yet\n", FONT_BOLD, FONT_NORMAL);
    }
    if (status == DRAW)
    {
        printf("\n%sUnfortunately, it's a draw...\n", FONT_BOLD);
    }
    else
    {
        printf("\n%sCongratulations: %s player has won!\n",
               board_data_colours[status], player_names[status]);
    }

    printf("%s\n", FONT_NORMAL);
}


int main()
{
    init_data();
    board_data current_player = RED;

    refresh_screen();

    game_status status = NOT_FINISHED;
    while (status == NOT_FINISHED)
    {
        printf("%sPlease enter the column number for player %s%s%s: ",
               FONT_NORMAL, board_data_colours[current_player],
               player_names[current_player], FONT_NORMAL);
        int column;
        int result = scanf("%i", &column);

        if (result != 1 || add_player_entry(current_player, column) == -1)
        {
            printf("%sERROR:%s column full or not a valid number, please try "
                   "again\n", FONT_BOLD, FONT_NORMAL);
            fflush(stdin);
        }
        else
        {
            refresh_screen();
            current_player = (current_player + 1) % NR_PLAYERS;
        }

        status = check_four_connected();
    }

    print_game_status(status);

    return 0;
}
