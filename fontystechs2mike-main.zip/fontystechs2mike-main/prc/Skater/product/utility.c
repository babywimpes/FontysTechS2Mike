#include "schaatser.h"
double bereken_gemiddelde_snelheid(struct Schaatser sb)
{
    const int distance= 2000;
    double time = sb.tijd500m+sb.tijd1500m;
    return distance/time;
}

