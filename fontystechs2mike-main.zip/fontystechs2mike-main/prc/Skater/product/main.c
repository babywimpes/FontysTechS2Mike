#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "utility.h"

#define AANTALSCHAATSERS 8
void Sort(struct Schaatser array[], int len){
    bool is_swapped= true;  
    while (is_swapped)
    {
        is_swapped = false;
        for (int j = 0; j < AANTALSCHAATSERS-1; j++)
        {
            if(array[j].gemiddelde_snelheid<array[j+1].gemiddelde_snelheid){
                struct Schaatser temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
                is_swapped = true;
               // printf("swapped %d and %d \n", array[j], array[j+1]);
            } 
        }        
    }
}

int main()
{
    int i2;
    printf("geef waarde");
    scanf("%i", &i2);
    printf("%i", i2);

    struct Schaatser ss[AANTALSCHAATSERS];

    for(int a = 0; a < AANTALSCHAATSERS; a++)
    {
        strcpy(ss[a].naam, "lakelakeman");
        strcpy(ss[a].nationaliteit, "limburg");
        ss[a].tijd500m = 0;
        ss[a].tijd1500m = 0;
        ss[a].gemiddelde_snelheid = bereken_gemiddelde_snelheid(ss[a]);
    }
 
    for(int b = 0; b < AANTALSCHAATSERS; b++){
        printf("%s, Nationaliteit: %s, Tijd500m: %i, Tijd1500m %i, Gemiddelde snelheid in m/s %f \n" , ss[b].naam, ss[b].nationaliteit, ss[b].tijd500m, ss[b].tijd1500m,ss[b].gemiddelde_snelheid );
    }
    
    return 0;
}

