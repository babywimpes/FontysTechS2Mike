#ifndef UTILITY_H
#define UTILITY_H
#include "schaatser.h"
double bereken_gemiddelde_snelheid(struct Schaatser sb);

#endif