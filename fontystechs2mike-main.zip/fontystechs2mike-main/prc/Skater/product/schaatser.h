#ifndef SCHAATSER_H
#define SCHAATSER_H
#define NAAMLENGTE 100
#define NATIONALITEITLENGTE 100

struct Schaatser{
    char naam[NAAMLENGTE];
    char nationaliteit[NATIONALITEITLENGTE];
    int tijd500m;
    int tijd1500m;
    double gemiddelde_snelheid;
};
#endif