#include "student.h"
#include "testData.h"
#include "utility.h"
#include <stdio.h>

#define STUDENTCOUNT 40
#define SEARCHTERM 've'


int main()
{
    Student students[STUDENTCOUNT];
    FillTestData(students, STUDENTCOUNT);
    ChangeCreditsAndSemester(students,STUDENTCOUNT);

    PrintStudent(students,STUDENTCOUNT);
    
    YoungestHighestStudent(students,STUDENTCOUNT);

    StudentSearch(students,STUDENTCOUNT);
    return 0;
}
