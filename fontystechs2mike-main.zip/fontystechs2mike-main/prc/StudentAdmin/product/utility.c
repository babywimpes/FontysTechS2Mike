#include "utility.h"
#include "student.h"
#include <stdio.h>
#include <string.h>
#include <strings.h>

#define MAX_STR_LEN 50

void PrintBar(int headerLenght){
    for(int i=0; i<headerLenght; i++){
        printf("=");
    }
    printf("\n");
}

void PrintStudent(Student students[], int STUDENTCOUNT){
    char bartmp[200];
    int headerlenghtfirst = sprintf(bartmp, "%-5s %-10s %-20s %10s %10s %10s\n","ID", "FirstName", "Surname","Age","Credits", "Semester" );
    PrintBar(headerlenghtfirst);

    int headerLenght= printf("%-5s %-10s %-20s %10s %10s %10s\n","ID", "FirstName", "Surname","Age","Credits", "Semester");
    PrintBar(headerLenght);
    for(int i=0; i<STUDENTCOUNT; i++){
        printf("%-5d %-10s %-20s %10d %10d %10d\n",i+1,students[i].FirstName,students[i].Surname, students[i].Age, students[i].Credits, students[i].CurrentSemester);
    }
    PrintBar(headerLenght);
}

void ChangeCreditsAndSemester(Student students[], int STUDENTCOUNT){
    for(int i=0; i<STUDENTCOUNT; i++){
        int tempCredit = students[i].Credits %30;
        students[i].Credits-= tempCredit;
    }
    for(int i=0; i<STUDENTCOUNT; i++){
        int tempSemester = students[i].Credits /30 + 1;
        students[i].CurrentSemester = tempSemester;
    }
}

Student YoungestHighestStudent(Student student [], int STUDENTCOUNT){
    int youngestage= 100;
    int highestresult= 0;
    Student youngesthigheststudent;
    for(int i=0; i<STUDENTCOUNT; i++){
        if(student[i].Age<youngestage){
            youngestage = student[i].Age;
        }
    }
    for(int i=0; i<STUDENTCOUNT; i++){
        if(student[i].Age == youngestage){
            if(student[i].Credits>highestresult){
                highestresult = student[i].Credits;
                youngesthigheststudent = student[i];
            }
        }
    }
    PrintStudent(&youngesthigheststudent, 1);
    return youngesthigheststudent;
}

void StudentSearch(Student student[], int STUDENTCOUNT)
{
    int loc=0;
    Student searchresults[STUDENTCOUNT];
    char search[MAX_STR_LEN];
    scanf("%s", search);

    int lenght = strlen(search);
    for(int i=0; i<STUDENTCOUNT; i++){
       int ret = strncasecmp(student[i].Surname, search, lenght);
       
        if (ret == 0){
            searchresults[loc]=student[i];
            loc++;       
        }
    }
    if (loc== 0){
        printf("no results have been found \n");
    }
    else{
        PrintStudent(searchresults, loc); 
    }
}