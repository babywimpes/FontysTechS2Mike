#ifndef TESTDATA_H
#define TESTDATA_H
#include "student.h" 

int FillTestData(Student array[], int length);

#endif
