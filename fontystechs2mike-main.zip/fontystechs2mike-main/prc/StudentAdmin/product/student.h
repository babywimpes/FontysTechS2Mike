
#ifndef STUDENT_H
#define STUDENT_H
#define MAXNAMELENGHT 50

typedef struct Student
{
    char FirstName[MAXNAMELENGHT];
    char Surname[MAXNAMELENGHT];
    int Age;
    int Credits;
    int CurrentSemester;
}Student;

#endif
