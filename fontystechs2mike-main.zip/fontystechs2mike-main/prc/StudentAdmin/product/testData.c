#include "testData.h"

static const Student Students[] =
{
    { "Saar",      "Verhoeven",        21,  60, -1 },
    { "Zayn",      "Dijkstra",         19,  61, -1 },
    { "Adam",      "Groot, de",        19,  90, -1 },
    { "Levi",      "Dijk, van",        18,   0, -1 },
    { "Julia",     "Heuvel, van den",  19, 120, -1 },
    { "Evi",       "Ven, van de",      18,  60, -1 },
    { "Mees",      "Boer, de",         17,  70, -1 },
    { "Fien",      "Veen, van",        17,  30, -1 },
    { "Boaz",      "Linden, van der",  21, 150, -1 },
    { "Sara",      "Hoekstra",         16,  35, -1 },
    { "Lauren",    "Huisman",          20,  60, -1 },
    { "Sophie",    "Schouten",         17,   0, -1 },
    { "Milan",     "Meijer",           17,  90, -1 },
    { "Benjamin",  "Leeuwen, van",     18,  30, -1 },
    { "Luuk",      "Mulder",           17,  60, -1 },
    { "James",     "Janssen",          16,   0, -1 },
    { "Mats",      "Jacobs",           19, 120, -1 },
    { "Nova",      "Postma",           17,   0, -1 },
    { "Emily",     "Veenstra",         19, 120, -1 },
    { "Bram",      "Hendriks",         20,  60, -1 },
    { "Noud",      "Peters",           20, 120, -1 },
    { "Liv",       "Koster",           18,  60, -1 },
    { "Siem",      "Wit, de",          19,   0, -1 },
    { "Anna",      "Dam, van",         19,  60, -1 },
    { "Elin",      "Scholten",         18,  60, -1 },
    { "Teun",      "Smits",            18,  60, -1 },
    { "Olivier",   "Haan, de",         18,  60, -1 },
    { "Luca",      "Smit",             21, 120, -1 },
    { "Noah",      "Jong, de",         18,  60, -1 },
    { "Jesse",     "Dekker",           20,  60, -1 },
    { "Mila",      "Veen, van der",    18,  60, -1 },
    { "Eva",       "Wal, van der",     18,  60, -1 },
    { "Sam",       "Vos",              19,  60, -1 },
    { "Olivia",    "Heijden, van der", 18,  60, -1 },
    { "Lieke",     "Peeters",          18,  60, -1 },
    { "Lotte",     "Maas",             18,  60, -1 },
    { "Emma",      "Broek, van den",   18,  60, -1 },
    { "Daan",      "Berg, van den",    18,  60, -1 },
    { "Mason",     "Bos",              19,  90, -1 },
    { "Lina",      "Brink, van den",   22, 150, -1 },
    { "Sofie",     "Post",             17,   0, -1 },
    { "Milou",     "Willems",          17,   0, -1 },
    { "Maud",      "Kuipers",          17,   0, -1 },
    { "Lynn",      "Kramer",           21,  60, -1 },
    { "Tess",      "Beek, van",        18,  60, -1 },
    { "Lars",      "Vermeulen",        18,  60, -1 },
    { "Noor",      "Prins",            18,  60, -1 },
    { "Ella",      "Wijk, van",        19,  60, -1 },
    { "Liam",      "Bakker",           17,  30, -1 },
    { "Yara",      "Vliet, van",       18,  60, -1 },
    { "Sem",       "Vries, de",        19,  90, -1 },
    { "Thomas",    "Meer, van der",    17,   0, -1 },
    { "Finn",      "Visser",           18,   0, -1 },
    { "Gijs",      "Kok",              16,   0, -1 },
    { "Max",       "Brouwer",          18,  60, -1 },
    { "Isa",       "Jonge, de",        18,  60, -1 },
    { "Julian",    "Graaf, de",        17,   0, -1 },
    { "Nina",      "Blom",             21,  60, -1 },
    { "Lucas",     "Jansen",           17,   0, -1 },
    { "Nora",      "Bruin, de",        19, 120, -1 }
};
static const int NrStudents = sizeof(Students) / sizeof(Students[0]);

/* Function: FillTestData
 * Parameters: array: will be filled with testdata
 *             length: max nr of students that can be written in array
 * Returns: number of students that have been copied
 */
int FillTestData(Student array[], int length)
{
    if (length > NrStudents)
    {
        length = NrStudents;
    }

    for (int i = 0; i < length; i++)
    {
        array[i] = Students[i];
    }

    return length;
}
