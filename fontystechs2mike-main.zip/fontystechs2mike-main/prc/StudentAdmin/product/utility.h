#ifndef UTILITY_H
#define UTILITY_H
#include "student.h" 


void PrintBar(int headerLenght);

void PrintStudent(Student students[], int STUDENTCOUNT);

void ChangeCreditsAndSemester(Student students[], int STUDENTCOUNT);

Student YoungestHighestStudent(Student student [], int STUDENTCOUNT);

void StudentSearch(Student student[], int STUDENTCOUNT);
#endif
