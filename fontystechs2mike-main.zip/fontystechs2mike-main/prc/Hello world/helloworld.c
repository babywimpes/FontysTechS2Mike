#include "stdio.h"

struct schaatser{
    int tijd500m;
    int tijd1500m;
    double gemiddelde_snelheid;
};

double bereken_gemiddelde_snelheid(struct schaatser sb)
{
    const int distance= 2000;
    double time = sb.tijd500m+sb.tijd1500m;
    return distance/time;
}

int main()
{
    const int count_schaatsers=8;
    struct schaatser ss[count_schaatsers];
    for(int a = 0; a < count_schaatsers; a++)
    {
        ss[a].tijd500m = 30+a;
        ss[a].tijd1500m = 100+a;
        ss[a].gemiddelde_snelheid = bereken_gemiddelde_snelheid(ss[a]);

    }

   
    for(int b = 0; b < count_schaatsers; b++){
        printf("Schaatser: Tijd500m: %i, Tijd1500m %i, Gemiddelde snelheid in m/s %f \n" , ss[b].tijd500m, ss[b].tijd1500m,ss[b].gemiddelde_snelheid );
    }
    
    return 0;
}
