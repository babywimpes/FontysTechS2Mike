#include <stdio.h>

#define MAXLENGHT 5

void swap(int* ptri, int* ptrj){

    int ptrtemp = *ptri;
    *ptri = *ptrj;
    *ptrj = ptrtemp;
}



int main(){
    //double i = 10;
    //double* p = &i;
    //*p = 40;
    int i = 200;
    int j = 40;
    int array[MAXLENGHT]={3,4,6,7,9};
    int* parray = &array[3];

    parray[-2] = 100;   
    parray[1]= 69;
    for(int i = 0; i < MAXLENGHT; i++){
        printf("%i \n",parray[i-3]);
    }

    swap(&i, &j);

    printf("i = %i, j =%i \n", i, j );

    return 0;
}

