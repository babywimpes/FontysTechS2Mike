#include <string.h>
#include <stdio.h>
#include <stdlib.h>


#define MAXSTRING 100

//returns -1 on error en 0 on succes
int StringInsertInefficient(char *srcstring, char *insertion, size_t index, size_t maxDestSize){
     int srclen = strlen(insertion);
    int destlen = strlen(srcstring);
    if(srcstring == NULL || insertion == NULL || srclen+destlen > maxDestSize) return -1;

    char temp[maxDestSize];
    strcpy(temp, srcstring);
   

    for(int i = 0; i < index; i++){
        srcstring[i] = temp[i]; 
    }
    for(int i = 0; i < srclen; i++){
        srcstring[i+index] = insertion[i];
    }
    for(int k = 0; k < destlen - index ; k++){
        //printf("%d", k);
        srcstring[k + index + srclen] = temp[k + index];
    }
    printf("%s \n", srcstring);

    return 0;
}

int StringInsert(char *srcstring, char *insertion, size_t index, size_t maxDestSize){

    int srclen = strlen(insertion);
    int destlen = strlen(srcstring);

    if(srcstring == NULL || insertion == NULL || (srclen + destlen) > maxDestSize) return -1;
    
    for (int i = 0; i < destlen + 1 - index; i++) {
        srcstring[destlen - i + srclen] = srcstring[destlen - i];
    }
    strncpy(srcstring + index, insertion, srclen);
    printf("%s \n",srcstring);


    return 0;
}

int main(){ 
    char insertion[MAXSTRING] = "";
    int pos;
    char srcstring[MAXSTRING] = "Hello World";
    printf("Enter a string to insert: ");
    scanf("%s", insertion);
    printf("\nOn position (0-12):  ");    
    scanf("%d", &pos);
    
    
   // StringInsertInefficient(srcstring, insertion, pos, MAXSTRING);
    StringInsert(srcstring, insertion, pos, MAXSTRING);
    for(int i = 0; i < MAXSTRING; i++){
       // printf("%2x ", srcstring[i]);
    }

    return 0;
}