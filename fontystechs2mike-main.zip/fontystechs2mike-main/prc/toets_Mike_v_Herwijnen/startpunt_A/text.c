#include "text.h"
#include <stdio.h>
#include <string.h>
// hex-bin conversie tabel:
// 0x0 = 0000
// 0x1 = 0001
// 0x2 = 0010
// 0x3 = 0011
// 0x4 = 0100
// 0x5 = 0101
// 0x6 = 0110
// 0x7 = 0111
// 0x8 = 1000
// 0x9 = 1001
// 0xA = 1010
// 0xB = 1011
// 0xC = 1100
// 0xD = 1101
// 0xE = 1110
// 0xF = 1111

// 0xAB is dus: 10101011b


// Voor deel E *KAN* je deze functie implementeren en gebruiken als jou dit handig
// lijkt, dit is geen verplichting!
static int check_parity(char c, char parity)
// pre : parity is 0 of 1
// post: geeft 1 terug als het aantal 1-en in c *en* parity samen oneven is,
//       anders 0.
//       Voorbeeld: c = 0xAA (1010 1010) en parity is 1 dan is het resultaat: 1
//       (4 enen in c en 1 in parity) voorbeeld: c = 0xAA (1010 1010) en parity
//       is 0 dan is het resultaat: 0 (4 enen in c, geen in parity) voorbeeld: c
//       = 0x01 (1010 1010) en parity is 0 dan is het resultaat: 1 (1 een in c,
//       geen in parity)
{
    int count = 0;
    for(int i = 0; i <= 7; i++)
    {
        if((c & (1 << i)) != 0)
        {
            count++;
        }
    }
    //printf("%d\n", (count + parity) % 2);

    if((count + parity) % 2 == 0) return 0;
    else return 1;

}


// Uncomment deze functie voor deel E
int str_remove_bad_chars(char* input, char* pariteit, char* output)
// pre : -
// post: telt voor elk karakter in input en de bijbehorende parity het aantal
// bits die 1 zijn, als dit aantal
//       oneven is dan wordt het karakter in output geschreven. Als dit aantal
//       even is wordt het karakter overgeslagen. Functie geeft 0 terug als
//       alles goed gaat, -1 in geval de functie zijn werk niet heeft kunnen
//       doen
// Let op: functie geeft dus gewoon 0 terug als hij 1 of meerdere parity fouten
// is tegengekomen! voorbeeld: input = "haoi" (0x68, 0x61, 0x6F, 0x69), pariteit
// = {0, 1, 1, 1} dan wordt output: "hoi"
//            (0x68 heeft 3 enen, parity is 0 dus is correct, 0x61 heeft 3 enen,
//            parity is 1 dus is fout, etc.)
{
    if(input == NULL || pariteit == NULL || output == NULL)
    {
        return -1;
    }

    int indexoutput = 1;

    for(size_t i = 0; i < strlen(input); i++)
    {
        if(check_parity(input[i], pariteit[i]) != 0)
        {
            output[indexoutput++] = input[i];
        }
    }

    return 0;

}


// Deel H: implementeer swap_bits en zorg dat deze op een nette manier
//         vanuit main.c aan te roepen is
char swap_bits(char input)
// pre : -
// post: geeft een kopie van input terug waarin bits 2 en 5 zijn omgewisseld
// (let op: bit 0 is het meest rechtse bitje) voorbeeld:
// input = 0xA8 (1010 1000) geeft als resultaat: 0x8C (1000 1100)
{
    char mask2 = 0x04;
    char mask5 = 0x20;

    char value2 = input & mask2;
    char value5 = input & mask5;
 
    input = input & ~mask2;
    input = input & ~mask5;

    input |= value5 >> 3;
    input |= value2 << 3;

    return input;
}
