#ifndef STRUCTUUR_H
#define STRUCTUUR_H

// Deel A

// Definieer een structuur met daarin het volgende:
//     een integer met naam: zonhoek
//     een double met naam: maanstand
// De structuur heeft als naam: rare_datum en moet als volgt
// te declareren zijn:
//     struct rare_datum c;

struct rare_datum {
    int zonhoek;
    double maanstand;
};



// Definieer een structuur met daarin het volgende:
//     een string waarin 80 karakters kunnen met naam: tekst 
//     een array van 80 characters met naam: pariteit
//     een int met naam: tekst_lengte
//     een struct rare_datum met naam: datum
// De structuur heeft als naam: data en moet als volgt
// te declareren zijn:
//     data d;

typedef struct data {
    char tekst[80];
    char pariteit[80];
    int tekst_lengte;
    struct rare_datum datum;
} data;


#endif