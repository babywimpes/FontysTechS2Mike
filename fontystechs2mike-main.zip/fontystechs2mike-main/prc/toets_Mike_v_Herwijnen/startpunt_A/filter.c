#include "filter.h"
#include <stdio.h>
#include <string.h>
// Deel D
// Implementeer Filter en zorg dat deze functie vanuit main.c te
// gebruiken is.


// Filter: Haal ongeldige data uit een array van 'data' structuren
//         Data is geldig als de zonhoek van een element hoger is
//         dan de zonhoek van het vorige element. Het eerste
//         element is altijd valide.
//         Voorbeeld: zonhoeken 2 17 16 17 20
//         In dit voorbeeld zijn de eerste 2 elementen en het
//         laatste element geldig. Het eerste element is altijd
//         geldig, 17 is groter dan 2 dus geldig, 16 is niet groter
//         dan 17 dus ongeldig, 17 is niet groter dan 17 dus
//         ongeldig en 20 is groter dan 17 dus geldig.
// input: array
// output: data in array is gewijzigd
// returns: -1 bij een fout,
//          anders het aantal overgebleven velden in array
int Filter( data* array, size_t nrofelements )
{
    data arrcpy[nrofelements];
    
   // printf("%ld\n", nrofelements);
    memcpy(arrcpy, array, nrofelements * sizeof(array[0]));

    int indexarray = 1;
    int indexarrcpy = 1;

    int count = 0;

    for(size_t i = 0; i < nrofelements; i++)
    {
        if(array[i-1].datum.zonhoek < arrcpy[i].datum.zonhoek)
        {
            array[indexarray++] = arrcpy[indexarrcpy++];
            count++;
        }
        else
        {
            indexarrcpy++;
        }
    }

    return count;    
}
