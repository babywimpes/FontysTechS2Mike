#include "unity.h"
#include "filter.h"
#include "text.h"
#include "structuur.h"
#include "testdata.h"

// I rather dislike keeping line numbers updated, so I made my own macro to ditch the line number
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

void setUp(void)
{
    // This is run before EACH test
}

void tearDown(void)
{
    // This is run after EACH test
}


// Deel F: maak zinnige unit testen voor str_remove_bad_chars (en evt andere functies)
// Let op: empty_test staat hier alleen om te zorgen dat deze "lege" file compileert.
// Het is de bedoeling dat je deze verwijdert nadat je zelf een test gemaakt hebt.
void empty_test(void)
{
    
    TEST_ASSERT_EQUAL(1, 0);
}

void test_parity(void){

    char test_string[10] =  {0110,0146,0154,0166,0165,0155,0146,0117,0114,0157};
    int test_parity[10] = {01,00,00,01,01,00,00,01,01,00};
   // char expected_string[10] = {1,0,0166,0165,0155,0146,0117,0114,0157};
    for(int i = 0; i < 10; i++){
        check_parity(test_string[i], test_parity[i]);
    }
   ;
}


int main (void)
{
    UnityBegin();
    
    MY_RUN_TEST(empty_test);
    
    return UnityEnd();
}
