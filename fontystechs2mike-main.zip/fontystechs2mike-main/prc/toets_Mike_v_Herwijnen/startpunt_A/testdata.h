#ifndef TESTDATA_H
#define TESTDATA_H

#include <stddef.h>
#include "structuur.h"

size_t GetNrElements();

int GetData(data* array);

#endif