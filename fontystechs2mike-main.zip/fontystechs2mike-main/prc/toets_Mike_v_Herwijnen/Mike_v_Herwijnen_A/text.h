#ifndef TEXT_H
#define TEXT_H

#include <stddef.h>

int str_remove_bad_chars(char* input, char* pariteit, char* output);
char swap_bits(char input);

#endif

