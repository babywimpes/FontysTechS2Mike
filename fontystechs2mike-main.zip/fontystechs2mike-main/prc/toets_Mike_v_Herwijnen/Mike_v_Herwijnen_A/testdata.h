#ifndef TESTDATA_H
#define TESTDATA_H

#include <stddef.h>  // Freddy: netjes, maar het is beter om eigen includes eerst neer te zetten
#include "structuur.h"

size_t GetNrElements();

int GetData(data* array);

#endif