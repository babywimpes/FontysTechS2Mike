#include "filter.h"
#include <stdio.h>
// Deel D
// Implementeer Filter en zorg dat deze functie vanuit main.c te
// gebruiken is.


// Filter: Haal ongeldige data uit een array van 'data' structuren
//         Data is geldig als de zonhoek van een element hoger is
//         dan de zonhoek van het vorige element. Het eerste
//         element is altijd valide.
//         Voorbeeld: zonhoeken 2 17 16 17 20
//         In dit voorbeeld zijn de eerste 2 elementen en het
//         laatste element geldig. Het eerste element is altijd
//         geldig, 17 is groter dan 2 dus geldig, 16 is niet groter
//         dan 17 dus ongeldig, 17 is niet groter dan 17 dus
//         ongeldig en 20 is groter dan 17 dus geldig.
// input: array
// output: data in array is gewijzigd
// returns: -1 bij een fout,
//          anders het aantal overgebleven velden in array
int Filter( data* array, size_t nrofelements )
{
    
    for(size_t i = 1; i < nrofelements; i++)
    {
        if(array[i].datum.zonhoek > array[i-1].datum.zonhoek)
        {
            for(size_t j = i; j < nrofelements-1; j++)
            {
                array[j] = array[j+1];
                printf("%s\n",array[j].tekst);
            }
            nrofelements--;
        }
    }

    return nrofelements;
}
