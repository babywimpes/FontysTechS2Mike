#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "filter.h"
#include "structuur.h"
#include "testdata.h"
#include "text.h"


// Deel I
int PrintData( data* array, size_t nr_elements )

// pre:
// post: alle data uit het array is naar het scherm geprint volgens het
// onderstaande formaat.
// return: 0 als alles goed gaat, -1 in geval van error.
{
    if(nr_elements != (sizeof array)){
        return -1;
    }
    for(size_t i = 0; i < nr_elements; i++){
        printf("%ld: \n", i);
        printf("%s\n", array[i].tekst);
        printf(" %d\n", array[i].tekst_lengte);
        printf("zonhoek: %d, maanstand: %f\n", array[i].datum.zonhoek, array[i].datum.maanstand);
        printf("\n");
    }

    return 0;
}

int main(void)
{
    // Deel C: declareer array en roep GetData aan
    size_t nr_elements = GetNrElements();
    data array[nr_elements];
    GetData(array);

    // Deel D: filter foutieve data.
    nr_elements = Filter(array, nr_elements);

    char output [nr_elements][80];

    for(size_t i = 0; i < nr_elements; i++){
        str_remove_bad_chars(array[i].tekst, array[i].pariteit, output[i]);
        printf("text: %s\n", output[i]);
    }
    // Deel G: roep str_remove_bad_chars aan op alle teksten in het array, zorg
    // dat de teksten in het array vervangen worden door de nieuwe tekst!
    // Gebruik eventueel het tekst_lengte veld om de resulterende string
    // te controleren

    // Deel H: roep swap_bits aan op alle overgebleven tekst in het array.

    // Deel I: roep PrintData aan
    PrintData(array, nr_elements);

    return 0;
}


