#ifndef FILTER_H
#define FILTER_H

#include "structuur.h"
#include <stddef.h>

int Filter( data* array, size_t nrofelements);

#endif
