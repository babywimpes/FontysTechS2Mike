#include <Arduino.h>
#include <Wire.h>

#define ARRAYSIZE 10

void setup()
{
  Wire.begin();
  Serial.begin(9600);
  Serial.print("hello world");
}

int WriteArray[ARRAYSIZE]={0};

bool readWireToIntArray(int nrRequestedBytes, int* pWriteArray, size_t MaxArraySize)
{
  if(MaxArraySize < nrRequestedBytes || pWriteArray == NULL){
    return false;
  }

  int index = 0;
  while(index < nrRequestedBytes)
  {
    int c = Wire.read(); 
    pWriteArray[index++] = c;
  }
  if(index < nrRequestedBytes){
    return false;
  }
  return true;
}

void loop()
{
  Wire.beginTransmission(4); // transmit to device #4
  Wire.write(22); 
  Wire.write(12);                         // sends one byte  
  Wire.endTransmission();    // stop transmitting

  Wire.beginTransmission(4); // transmit to device #4
  Wire.write(23); 
  Wire.write(123);                         // sends one byte  
  Wire.endTransmission(); 
  
  Wire.beginTransmission(4); // transmit to device #4
  Wire.write(24);                         // sends one byte  
  Wire.endTransmission(); 

  Wire.requestFrom(4, 1); 

  readWireToIntArray(1, WriteArray, ARRAYSIZE);

  delay(500);
}

