#include "mva.h"

int mva_calculate( const double* array, 
	              size_t array_length, 
				  size_t moving_average_length,
				    double* array_out,
				  size_t array_out_length)
{
	if (array == NULL || array_out == NULL || array_out_length == 0 || array_length == 0 || moving_average_length > array_length || moving_average_length == 0)
	{
		return -1;
	}

	for(int i = 0; i< array_out_length; i++)
	{
		double sum = 0;
		for(int j = 0; j < moving_average_length; j++)
		{
			sum += array[i+j];
		}
		array_out[i] = sum/moving_average_length;
	}
	return 0;
}