
//#include "lip.h"

#include <Arduino.h>
#include <math.h>
#include "mva.h"


int CalcLineair(int x, double *result, unsigned long *time ){
  if(result == NULL || time == NULL){
    return -1;
  }
  *time = micros();
  *result = (0.0287 * x + 17.981);
  *time = (micros() - *time);
  return 1;
}

float CalcExponential(int x, double *result, unsigned long *time){
  if(result == NULL || time == NULL){
    return -1;
  }
  *time = micros();
  *result = (25.305 * pow(M_E, -0.004 * x));
  *time = (micros() - *time);
  return 1;
}

float CalcPolynomial(int x, double *result, unsigned long *time){
  if(result == NULL || time == NULL){
    return -1;
  }
  *time = micros();
  *result = ((-4 * pow(10, -7) * pow(x, 3)) + (0.0005 * pow(x, 2)) - (0.233 * x) + 42.311);
  *time = (micros() - *time);
  return 0;
}

void printdata(int val, double *result, unsigned long *time){
  Serial.print("Data: ");
  Serial.print(val);
  Serial.print("\t Result: ");
  Serial.print(*result);  
  Serial.print("cm. \n Time: ");
  Serial.print(*time);
  Serial.println("us.");
}

void setup() {
  Serial.begin(9600);
}

void loop() {

  float array[] = {140, 400, 500, 400, 200};
	size_t array_length = sizeof(array)/sizeof(array[0]);
	size_t moving_average_length = array_length;
	float array_out[1] = {0,};
	size_t array_out_length = 1;

  double result = 0;
  unsigned long time = 0;

  for(size_t i = 0; i < array_length; i++){
    Serial.println("Lineair");
    CalcLineair(array[i], &result, &time);
    printdata(array[i], &result, &time);
    
    Serial.println("Exponential");
    CalcExponential(array[i], &result, &time);
    printdata(array[i], &result, &time);
    
    Serial.println("Polynomial");
    CalcPolynomial(array[i], &result, &time);
    printdata(array[i], &result, &time);
  }
  mva_calculate(array, array_length, moving_average_length, array_out, array_out_length);
  Serial.print("Moving average");
  Serial.println(array_out[0]);
  delay(1000);
}