﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO.Ports;

namespace GUI
{
	class Connection
	{
		private SerialPort _serialPort;

		private RichTextBox RRtb;
		private RichTextBox SRtb;
		private Label ConnStatus;

		private Socket Sock_send;
		private Socket Sock_recv;

		private const string ID = "5";
		public Connection(int port, RichTextBox rrtb, RichTextBox srtb, Label connStatus)
		{
			this.RRtb = rrtb;
			this.SRtb = srtb;
			this.ConnStatus = connStatus;

			Sock_send = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

			Sock_recv = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			Sock_recv.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
			Sock_recv.Bind(new IPEndPoint(IPAddress.Any, port));
			Sock_recv.Listen(5);

			_serialPort = new SerialPort();
			_serialPort.PortName = "COM4";
			_serialPort.BaudRate = 9600;
			_serialPort.Open();
		}

		public string send_connected()
		{
			return Sock_send.Connected ? "Connected" : "Not connected";
		}

		public string recv_connected()
		{
			return Sock_recv.Connected ? "Connected" : "Not connected";
		}

		public void StartRecv()
        {
			Thread recv_thread = new Thread(recv_loop);
			recv_thread.Start();
		}

		public void connect(string ip)
		{
			Sock_send.Connect(IPAddress.Parse(ip), 5678);
			SendSetTextBox("Verbonden");
		}

		public void Send(string text)
        {
			Sock_send.Send(Encoding.ASCII.GetBytes(text));
        }

		private void recv_loop()
		{
			while (true)
			{
				Socket client = Sock_recv.Accept();
				RecvSetTextBox("Iemand is verbonden");
				while (client.Connected)
				{
					byte[] buffer = new byte[1024];
					client.Receive(buffer, SocketFlags.None);

					string message = Encoding.ASCII.GetString(buffer);

					if(message.Substring(0,1) == "#")
					{
						int index = message.IndexOf(':');
						if(message.Substring(1,index-1)== ID)
						{
							int indexProcent = message.IndexOf('%');
							string command = "#" + message.Substring(index + 1, indexProcent-1);
							RecvSetTextBox(command);
							_serialPort.Write(command);
						}
						else
						{
							Send(message);
						}

					}
				}
			}
		}

		public void RecvSetTextBox(String text)
		{
			if (RRtb.InvokeRequired)
			{
				RRtb.Invoke((MethodInvoker)delegate () { RecvSetTextBox(text); });
				return;
			}
			RRtb.Text += text + "\n";
		}

		public void SendSetTextBox(String text)
		{
			if (ConnStatus.InvokeRequired)
			{
				ConnStatus.Invoke((MethodInvoker)delegate () { SendSetTextBox(text); });
				return;
			}
			ConnStatus.Text = text + "\n";
		}
	}
}
