﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Connection conn;
        
        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new Connection(5678, rtb_recv, rtb_send, connStatus);
            conn.StartRecv();
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            conn.connect(txt_ip.Text);
            btn_connect.Enabled = false;
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
           // int userid = int.Parse(textBoxUserID.Text);
            //string command = textBoxCommand.Text;
            //string fullmessage = "#" + userid + ":" +command+ "%";
            conn.Send(rtb_send.Lines[rtb_send.Lines.Length - 1]);
        }
    }
}
