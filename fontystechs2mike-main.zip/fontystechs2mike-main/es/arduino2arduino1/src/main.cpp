#include <Arduino.h>
#include <SoftwareSerial.h>
SoftwareSerial link(2, 3);

void setup() {
  link.begin(9600);
  Serial.begin(9600);

}

void loop() {
  //Serial.write("ON");
  link.println("abc");
  delay(1000);
  //Serial.write("OFF");
  link.println("def");
  delay(1000);
}