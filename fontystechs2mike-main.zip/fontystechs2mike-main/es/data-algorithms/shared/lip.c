#include "lip.h"

// leave resource_detector.h as last include!
#include "resource_detector.h"

/* 
 * @param x_array: pointer to an array containing x-values
 * @param y_array: pointer to an array containing y-values
 * @param array_length: length of the x- and y-array
 * 
 * @param x: x value for which interpolation should be applied
 * @param yPtr: pointer to where the interpolated y-value should be stored
 *
 * @return -1 : x-array, y_array or yPtr are NULL
 *         -1 : measured_x is not within range of values within x_array
 *         -1 : array_length is not larger then 2
 *		    0 : calculation is succesfull
 */

int lip_calculate(const float *x_array,
				   const float *y_array,		
				   size_t array_length,
				   float x, 
				   float *yPtr)
{

	if(x_array == NULL || y_array == NULL || yPtr == NULL || array_length < 2 )
	{
		return -1;
	}

	for(int i = 0; i < array_length - 1; i++)
	{
		if(x < x_array[0] || x > x_array[array_length-1])
		{
			return -1;
		}
		else if(x > x_array[i] && x < x_array[i+1])
		{
			*yPtr = y_array[i] + (y_array[i+1] - y_array[i]) / (x_array[i+1] - x_array[i]) * (x - x_array[i]);			
		}
	}
	return 0;
}
