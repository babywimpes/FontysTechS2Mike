#ifndef LIP_H
#define LIP_H

#include <stddef.h>

/* 
 * @param x_array: pointer to an array containing x-values
 * @param y_array: pointer to an array containing y-values
 * @param array_length: length of the x- and y-array
 * 
 * @param x: x value for which interpolation should be applied
 * @param yPtr: pointer to where the interpolated y-value should be stored
 *
 * @return -1 : x-array, y_array or yPtr are NULL
 *         -1 : measured_x is not within range of values within x_array
 *         -1 : array_length is not larger then 2
 *		    0 : calculation is succesfull
 */
int lip_calculate(const float *x_array,
				  const float *y_array,		
				  size_t array_length,
				  float x, 
				  float *yPtr);

#endif
