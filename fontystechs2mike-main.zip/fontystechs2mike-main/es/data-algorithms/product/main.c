#include <stdio.h>
#include "mva.h"
#include "lip.h"

// leave resource_detector.h as last include!
#include "resource_detector.h"

int main(int argc, char* argv[])
{	
	printf("Hello mva and lip!\n");

	return (0);
}
