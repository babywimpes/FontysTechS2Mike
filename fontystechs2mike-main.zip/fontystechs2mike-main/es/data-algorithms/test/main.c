#include "mva.h"
#include "lip.h"
#include "unity.h"
#include "unity_test_module.h"

#include <stdio.h>

// leave resource_detector.h as last include!
#include "resource_detector.h"

extern void run_mva_tests();
extern void run_lip_tests();

int main (int argc, char * argv[])
{
  UnityTestModule allModules[] = { { "mva", run_mva_tests},
                                   { "lip", run_lip_tests}                                   
                                 };

  size_t number_of_modules = sizeof(allModules)/sizeof(allModules[0]);

  return UnityTestModuleRun(argc, argv, allModules, number_of_modules);
}
