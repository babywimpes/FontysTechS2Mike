#include "mva.h"
#include "unity.h"
#include "unity_test_module.h"
#include <stdio.h>

// I rather dislike keeping line numbers updated, so I made my own macro to ditch the line number
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

// leave resource_detector.h as last include!
#include "resource_detector.h"

void mva_setUp(void)
{
    //printf("This is run before EACH test.\n");
}

void mva_tearDown(void)
{
    //printf("This is run after EACH test.\n");
}

void mva_test_simplest_moving_average()
{
	float array[] = {1, 4, 5, 4, 2};
	size_t array_length = sizeof(array)/sizeof(array[0]);
	size_t moving_average_length = array_length;

	float array_out[1] = {0,};
	size_t array_out_length = 1;

	int r = mva_calculate(array, array_length, 
	                     moving_average_length, 
						 array_out, array_out_length); 

	TEST_ASSERT_EQUAL(0, r);
	TEST_ASSERT_FLOAT_WITHIN(1e-4, 3.2, array_out[0]);
}

void mva_test_moving_average_of_constant_numbers()
{
	float some_constant = 2;
    float array[10] = {some_constant, }; 
    for(int i = 0; i < 10; i++)
    {
        array[i] = some_constant; 
    }

    // All numbers at set to same constant 
    size_t array_length = sizeof(array)/sizeof(array[0]);
    size_t moving_average_length = 5;

    float array_out[6] = {0,};
    size_t array_out_length = 6; // 10 - 5 + 1

    int r = mva_calculate(array, array_length, 
                         moving_average_length, 
                         array_out, array_out_length); 

    TEST_ASSERT_EQUAL(0, r);

    for(int i = 0; i < array_out_length; i++)
    {
        printf("%f\n", array_out[i]);
        TEST_ASSERT_FLOAT_WITHIN(1e-4, some_constant, array_out[i]);
    }

}

void run_mva_tests()
{
    UnityRegisterSetupTearDown( mva_setUp, mva_tearDown);

    MY_RUN_TEST(mva_test_simplest_moving_average);
	MY_RUN_TEST(mva_test_moving_average_of_constant_numbers);
    
    UnityUnregisterSetupTearDown();
}
