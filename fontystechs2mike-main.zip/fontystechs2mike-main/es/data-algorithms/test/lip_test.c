#include "lip.h"
#include "unity.h"
#include "unity_test_module.h"

#include <stdio.h>

// I rather dislike keeping line numbers updated, so I made my own macro to ditch the line number
#define MY_RUN_TEST(func) RUN_TEST(func, 0)

// leave resource_detector.h as last include!
#include "resource_detector.h"

void lip_setUp(void)
{
    //printf("This is run before EACH test.\n");
}

void lip_tearDown(void)
{
    //printf("This is run after EACH test.\n");
}

void lip_test_simple_interpolation()
{
    float x_array[] = {0,1,2,3};
    float y_array[] = {0,1,4,9};
    size_t array_length = sizeof(x_array)/sizeof(x_array[0]);
    float x = 1.5;
    float y = 0;

	int r = lip_calculate(x_array, y_array, array_length,
                          x, 
                          &y);

    TEST_ASSERT_EQUAL(0, r);
	TEST_ASSERT_FLOAT_WITHIN(1e-4, 2.5, y);
}

void run_lip_tests()
{
    UnityRegisterSetupTearDown( lip_setUp, lip_tearDown);

    MY_RUN_TEST(lip_test_simple_interpolation);
    
    UnityUnregisterSetupTearDown();
}
