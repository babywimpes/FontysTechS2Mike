#include <Arduino.h>
#include <SoftwareSerial.h>

SoftwareSerial link(2, 3);

 char cString[4];
  byte chPos = 0;
  byte ch = 0;

void setup() {
  link.begin(9600);
  Serial.begin(9600);
  pinMode(9,OUTPUT);
}

void loop() {
  while(link.available())
  {
    //read incoming char by char:
    ch = link.read();
    cString[chPos] = ch;
    chPos++;
    if(chPos>3){
      chPos=0;
      Serial.print(cString);  
      int res = strncmp(cString, "abc", 3);
       
      if(res ==0){
        digitalWrite(9,HIGH);
        //Serial.println("aan");
      }
      else{
        digitalWrite(9,LOW);
        //Serial.println("uit");
      }
      memset(cString,0,sizeof(cString));
    }
  }   
}