#ifndef MVA_H
#define MVA_H

#include <stdint.h>
#include <stddef.h>

/* 
 * @param array: pointer to an array containing values
 * @param array_length: length of the array
 * @param moving_average_length: length of the moving average filter
 *  
 * @param array_out: pointer to where the array of 
 *                   moving average values must be stored
 * @param array_out_length: length of the array_out
 *
 * @return -1 : array or array_out is NULL
 	  	   -1 : array_out_length does not match the exact required size
		    0 : calculation is succesfull
*/
int mva_calculate(const double* array, 
	              size_t array_length, 
				  size_t moving_average_length,
				  double* array_out,
				  size_t array_out_length);

#endif
