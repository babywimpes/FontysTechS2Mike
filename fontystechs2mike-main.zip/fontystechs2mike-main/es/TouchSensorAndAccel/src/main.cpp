#include "mva.h"
#include <Arduino.h>
#include <Wire.h> // I2C

#define I2C_SLAVE_ADRESS 0x68 // I2C address of the sensor
#define I2C_REG_TEMPERATURE 0x41 // Configuration regis

#define HEATER_ON_TEMP 18 // Temperature at which the heater is turned on
#define HEATER_OFF_TEMP 22 // Temperature at which the heater is turned off

typedef enum { 
  HEATER_OFF, HEATER_ON, IDLE,
} HeaterState;

void setup() {
  Serial.begin(9600);
  Wire.begin();
}

HeaterState heaterState = IDLE;

double ReadTempFromReg(){
  Wire.beginTransmission(I2C_SLAVE_ADRESS);
  Wire.write(I2C_REG_TEMPERATURE);
  Wire.endTransmission();
  Wire.requestFrom(I2C_SLAVE_ADRESS, 2);
  uint16_t data = Wire.read() << 8 | Wire.read();
  return  data / 333.87 + 17;
}

void loop() {
//read value from wire and print it
  double temp = ReadTempFromReg();
  Serial.println(temp);
  if(heaterState == HEATER_OFF) {
 
    if(temp < HEATER_ON_TEMP) {

  
      heaterState = HEATER_ON;
      Serial.println("Heater on");
    }
  } 
  
  else if(heaterState == HEATER_ON) {
   if(temp > HEATER_OFF_TEMP) {
      heaterState = HEATER_OFF;
      Serial.println("Heater off");
    }
  }
  else {
    heaterState = IDLE;
  }
}