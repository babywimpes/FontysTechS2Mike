#include <Arduino.h>

#define MESSAGE_START ('#')
#define MESSAGE_STOP (';')
#define MAX_TIME_SINCE_LAST_MESSAGE (2500)

void setup() {
  // put your setup code here, to run once:
}

void loop() {
  // put your main code here, to run repeatedly:
}