#include <Arduino.h>

#define ALARMPIN  (9)

void sensor_begin()
{
  pinMode(ALARMPIN, INPUT);
}

boolean sensor_isTriggered()
{
  return digitalRead(ALARMPIN);
}

