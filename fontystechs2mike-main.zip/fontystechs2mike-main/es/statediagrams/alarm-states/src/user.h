#ifndef USER_H
#define USER_H

void user_begin();

boolean user_button_isPressed();

void user_turnAlarmSignalsOn();

void user_turnAlarmSignalsOff();

void user_showAlarmOn();

void user_showAlarmOff();

#endif
