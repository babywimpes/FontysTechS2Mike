#ifndef SENSOR_H
#define SENSOR_H

void sensor_begin();

boolean sensor_isTriggered();

#endif
