#include <Arduino.h>

#include "state.h"
#include "light.h"
#include "timer.h"

LIGHT_EVENT state_e2s(bool buttonPressed)
{
  LIGHT_EVENT event = EVENT_NONE;

  if (buttonPressed)
  {
    event = EVENT_BUTTON;
  }
  else if (timer_hasElapsed())
  {
    event = EVENT_TIMER_EXPIRED;
  }
  return event;
}

void state_s2s(LIGHT_STATE state, LIGHT_EVENT event, LIGHT_STATE *newState)
{
  switch (state)
  {
  case LIGHT_ON:
    light_turnOn();
    if (event == EVENT_BUTTON || event == EVENT_TIMER_EXPIRED)
    {
      timer_reset();
      Serial.println("LED OFF");
      *newState = LIGHT_OFF;
    }
    break;

  case LIGHT_OFF:
    light_turnOff();
    if (event == EVENT_BUTTON)
    {
      timer_start(lightOnDurationInMs);
      Serial.println("LED ON");
      *newState = LIGHT_ON;
    }
  default:
    break;
  }
}