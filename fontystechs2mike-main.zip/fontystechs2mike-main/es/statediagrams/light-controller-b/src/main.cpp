#include <Arduino.h>

#include "button.h"
#include "light.h"
#include "state.h"

#define BUTTONPIN (10)
#define LEDPIN (13)

void setup()
{
  Serial.begin(9600);
  Serial.println("Light controller started!");
  button_begin(BUTTONPIN);
  light_begin(LEDPIN);
}

void loop()
{
  static LIGHT_EVENT currentEvent = EVENT_NONE;
  static LIGHT_STATE lightState = LIGHT_OFF;
  static LIGHT_STATE newState = LIGHT_OFF;

  boolean buttonPressed = button_isPressed();

  if (buttonPressed)
  {
    Serial.println("Button pressed");
  }

  currentEvent = state_e2s(buttonPressed);
  state_s2s(lightState, currentEvent, &newState);
  if (currentEvent != EVENT_NONE)
  {
    if (newState != lightState)
    {
      lightState = newState;
    }
  }
}
