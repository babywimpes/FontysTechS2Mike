#include <Arduino.h>

int light_ledpin = 13;

void light_begin(int ledpin)
{  
  light_ledpin = ledpin; // comment
  pinMode(light_ledpin, OUTPUT);  
}

void light_turnOn()
{
  digitalWrite(light_ledpin, HIGH);
}

void light_turnOff()
{
  digitalWrite(light_ledpin, LOW);
}
