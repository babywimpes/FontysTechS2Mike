#ifndef STATE_H
#define STATE_H

typedef enum
{
  LIGHT_ON,
  LIGHT_OFF
} LIGHT_STATE;

typedef enum
{
  EVENT_NONE,
  EVENT_TIMER_EXPIRED,
  EVENT_BUTTON
} LIGHT_EVENT;

const int lightOnDurationInMs = 2500;
LIGHT_EVENT state_e2s(bool buttonPressed);
void state_s2s(LIGHT_STATE state, LIGHT_EVENT event, LIGHT_STATE *newState);

#endif
