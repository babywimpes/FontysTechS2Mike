#include <Arduino.h>

#include "state.h"

String state_e2s(LIGHT_EVENT event)
{
  switch(event)
  {
    case EVENT_TIMER_EXPIRED:
    return "TIMER-EXPIRED";
    break;
    case EVENT_BUTTON:
    return "BUTTON";
    break;
    default:
    break;
  }

  return "NONE";
}

String state_s2s(LIGHT_STATE state)
{
  switch(state)
  {
    case LIGHT_ON:
    return "LIGHT-ON";
    break;
    case LIGHT_OFF:
    return "LIGHT-OFF";
    break;
  }

  return "UNKNOWN";
}
