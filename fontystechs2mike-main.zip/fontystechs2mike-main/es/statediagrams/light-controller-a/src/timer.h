#ifndef TIMER_H
#define TIMER_H

void timer_start(long duration);

void timer_reset();

boolean timer_hasElapsed();

#endif
