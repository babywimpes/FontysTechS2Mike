#include <Arduino.h>

#include "button.h"
#include "timer.h"
#include "light.h"
#include "state.h"

#define BUTTONPIN (10)
#define LEDPIN    (13)

const int lightOnDurationInMs = 2500;

void setup() 
{
  Serial.begin(9600);  
  Serial.println("Light controller started!");
  button_begin(BUTTONPIN);
  light_begin(LEDPIN);
}

void loop()
{
  static bool ledIsOn = false;
  boolean buttonPressed = button_isPressed();
  boolean timerElapsed = timer_hasElapsed();
  
  if(buttonPressed || timerElapsed) 
  {
    Serial.println("Button pressed");
    if(ledIsOn) 
    {
      light_turnOff();
      ledIsOn = false;
      timer_reset();
    }
    else
    {
      light_turnOn();
      ledIsOn = true;
      timer_start(lightOnDurationInMs);      
    }
  } 
}
