#ifndef BUTTON_H
#define BUTTON_H

void button_begin(int buttonpin);
boolean button_isPressed();

#endif
