#include <Arduino.h>

static bool timerStarted = false;
static unsigned long timerEnd = 0;

void timer_start(long duration)
{
  timerEnd = millis() + duration;
  timerStarted = true;
}

void timer_reset()
{
  timerStarted = false;
}

boolean timer_hasElapsed()
{
  if (timerStarted && (millis() > timerEnd) )
  {
    return true;
  }

  return false;
}
