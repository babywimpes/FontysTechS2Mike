#include <Arduino.h>

#include "button.h"

int user_buttonpin = 10;

void button_begin(int buttonpin)
{
  user_buttonpin = buttonpin;
  pinMode(user_buttonpin, INPUT);
}

boolean button_isPressed()
{
  /* Poor implementation, don't use this as a reference... */
  if (digitalRead(user_buttonpin) == HIGH)
  {
    while (digitalRead(user_buttonpin) != LOW) {
      Serial.println("Waiting for button release...");
    }
    return true;
  }

  return false;
}
