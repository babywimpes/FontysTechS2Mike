#ifndef STATE_H
#define STATE_H

typedef enum
{
  LIGHT_ON,
  LIGHT_OFF
} LIGHT_STATE;

typedef enum
{
  EVENT_NONE,
  EVENT_TIMER_EXPIRED,
  EVENT_BUTTON
} LIGHT_EVENT;

String state_e2s(LIGHT_EVENT event);
String state_s2s(LIGHT_STATE state);

#endif
