#ifndef LIGHT_H
#define LIGHT_H

void light_begin(int ledpin);
void light_turnOn();
void light_turnOff();

#endif
