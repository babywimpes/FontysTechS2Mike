﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace SocketClient
{
    class Program
    {
        static void Main(string[] args)
        {
            const int port = 13000;
            String sendLine = "bericht";
            try
            {
                TcpClient clientSock = new TcpClient();
                Console.WriteLine("Connecting to Server ...");
                clientSock.Connect("145.93.124.57", port);


                NetworkStream stream = clientSock.GetStream();
                byte[] data = Encoding.ASCII.GetBytes(sendLine);
                Console.WriteLine("Sending message to the Server");
                stream.Write(data, 0, data.Length);

                while (true)
                {
                    sendLine = Console.ReadLine();
                    data = Encoding.ASCII.GetBytes(sendLine);
                    Console.WriteLine("Sending message to the Server");
                    stream.Write(data, 0, data.Length);
                    if (sendLine == "quit") break;
                }
                clientSock.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }
    }
}
