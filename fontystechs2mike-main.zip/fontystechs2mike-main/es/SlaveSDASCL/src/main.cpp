#include <Arduino.h>
#include <Wire.h>
int pos = 2;

int a = 0;
int b = 0;
int x;
void receiveEvent(int howMany)
{
  while(0 < Wire.available()) 
  {
    x = Wire.read();
    Serial.println(x);
    if(Wire.available() > 0){
      switch(x){
        case 22:
          a = Wire.read();

          break;
        case 23:
          b = Wire.read();
          break;
        default:
        Serial.println("not my command");
          break;
      }
    }
  }
}

void requestEvent()
{
   switch(x){
      case 22:
        Wire.write(a);
        //Serial.println(a);
        break;
      case 23:
        Wire.write(b);
        break;
      case 24:
        Wire.write(min(a,b));
        break;
      case 25:
        Wire.write(max(a,b));
        break;
      default:
      Serial.println("not my command");
        break;
  Wire.write(1);
  } // respond with message of 6 bytes
}

void setup()
{
  Wire.begin(4);                // join i2c bus with address #4
  Wire.onReceive(receiveEvent); // register event
  Wire.onRequest(requestEvent);
  Serial.begin(9600);           // start serial for output
}

void loop()
{
  delay(100);
}
