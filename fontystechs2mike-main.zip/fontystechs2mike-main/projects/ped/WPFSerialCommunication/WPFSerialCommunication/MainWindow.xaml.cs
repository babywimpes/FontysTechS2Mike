﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;

namespace WPFSerialCommunication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SerialPort _serialPort;
        
        public MainWindow()
        {
            InitializeComponent();
            _serialPort = new SerialPort();
            _serialPort.PortName = "COM4";
            _serialPort.BaudRate = 9600;
            _serialPort.Open();
        }


        private void btnClickSolid(object sender, RoutedEventArgs e)
        {
            try
            {
                Color c = ColorPicker.SelectedColor.Value;
                int red = c.R;
                int green = c.G;
                int blue = c.B;
                string message = "#Solid;" + red + "," + green + "," + blue + "%";
                MessageBox.Show(message);
                _serialPort.Write(message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           

        }

        private void btnClickRainbow(object sender, RoutedEventArgs e)
        {
            try
            {

                string message = "#Rainbow%";
                MessageBox.Show(message);
                _serialPort.WriteLine(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
