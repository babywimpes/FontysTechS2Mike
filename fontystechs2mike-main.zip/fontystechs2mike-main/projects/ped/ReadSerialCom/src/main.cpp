#include <Arduino.h>

int ledpin = 22;
char incomingByte;

void setup() {
  Serial.begin(9600);
  pinMode(ledpin, OUTPUT);
}

void loop() {
  
  if (Serial.available() > 0) {
    incomingByte = Serial.read();
    
    // say what you got:
   
   if(incomingByte == '1'){
     digitalWrite(ledpin,HIGH);
     delay(500);
   }
   
  }
}
