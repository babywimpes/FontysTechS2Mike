#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <stdlib.h>

#define LED_STRIP_PIN         26
#define NUMPIXELS         10

char incomingByte;
String command;
bool reading = false;

Adafruit_NeoPixel strip(NUMPIXELS, LED_STRIP_PIN, NEO_GRB + NEO_KHZ800);

void Solid(int r, int g, int b){
  for(int n =0; n<NUMPIXELS; n++){
    strip.setPixelColor(n,r,g,b);
    strip.show();
    delay(100);
  }

}

void Rainbow(){
  int rainbow[10][3] = {
    {100,0,0}, {100,50,0}, {100,100,0}, {50,100,0}, {0,100,0}, {0,100,50},{0,100,100},{0,50,100},{0,0,100},{0,0,50}
  };

  for(int n =0; n<NUMPIXELS; n++){

    int r = rainbow[n][0];
    int g = rainbow[n][1];
    int b = rainbow[n][2];

    strip.setPixelColor(n,r,g,b);
    strip.show();
    delay(100);
  }
}

void Pixel(int pixel, int r, int g, int b){
  if(pixel < NUMPIXELS && pixel > 0){   
    strip.setPixelColor(pixel,r,g,b);
    strip.show();
  }
}

void Disco(){
  for(int i = 0; i<NUMPIXELS; i++){
    int r = rand()%200 + 10;
    int g = rand()%200 + 10;
    int b = rand()%200 + 10;
    strip.setPixelColor(i,r,g,b);
    strip.show();
    delay(100);
  }
}

void Clear(){
  for(int n =0; n<NUMPIXELS; n++){
    strip.setPixelColor(n,0,0,0);
    strip.show();
    delay(100);
   }
}

void setup() {
  Serial.begin(9600);
  strip.begin();
  strip.show();

}

void loop() {
 
  if(Serial.available() > 0){
    incomingByte = Serial.read();
    if(incomingByte =='#'){
      reading = true;
      //Solid(10,100,10);
    }

    while (reading)
    {
      while (!Serial.available());
      incomingByte = Serial.read();
      if(incomingByte =='%'){
        reading = false;
        //Solid(100,10,10);
      }
      else{
        command += incomingByte;
      }
    }
    if(command =="Rainbow"){
      Rainbow();
      command="";
    }
    else if(command =="Disco"){
      Disco();
      command="";
    }
    else if(command=="Clear"){
      Clear();
      command="";
    }
    else if(command.startsWith("Solid;")){
      int indexstart = command.indexOf(";");
      String parameter = command.substring(indexstart+1,command.length());
      char chararray [parameter.length()];
      for(int j = 0; j < sizeof(chararray); j++) {
        chararray[j] = parameter[j];
      }
      char *ptr;
      ptr = strtok(chararray, ",");
      int rgbsolid[3]={};
      for(int j= 0; j<3; j++){
        int sum = atoi(ptr);
        rgbsolid[j] = sum;
        Serial.println(ptr);
        ptr = strtok(NULL, ",");
      }  
      Solid(rgbsolid[0],rgbsolid[1],rgbsolid[2]); 
      command="";
    } 

    else if(command.startsWith("Pixel;")){
      int indexstart = command.indexOf(";");
      String parameter = command.substring(indexstart+1,command.length());
      char chararray [parameter.length()];
      for(int j = 0; j < sizeof(chararray); j++) {
        chararray[j] = parameter[j];
      }
      char *ptr;
      ptr = strtok(chararray, ",");
      int rgbsolidpixel[4]={};
      for(int j= 0; j<4; j++){
        int sum = atoi(ptr);
        rgbsolidpixel[j] = sum;
        Serial.println(ptr);
        ptr = strtok(NULL, ",");
      }  
      Pixel(rgbsolidpixel[0]-1,rgbsolidpixel[1],rgbsolidpixel[2],rgbsolidpixel[3]);
    }
  } 
}
