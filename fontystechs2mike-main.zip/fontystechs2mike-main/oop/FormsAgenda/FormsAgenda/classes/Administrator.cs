﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public class Administrator
    {
        public List<AgendaItem> agendaItems;
        public List<Contacts> contactsList;
        public Administrator()
        {
            agendaItems = new List<AgendaItem>();
            contactsList = new List<Contacts>();
        }


        public bool AddAgendaItem(AgendaItem agendaItem)
        {
            if (agendaItem != null)
            {
                agendaItems.Add(agendaItem);
                return true;
            }
            else
            {
                throw new ArgumentNullException("agendaItem");
            }
        }

        public bool RemoveAgendaItem(AgendaItem agendaItem)
        {
            if (agendaItem != null)
            {
                agendaItems.Remove(agendaItem);
                return true;
            }
            else
            {
                throw new ArgumentNullException("error removing agendaitem");
            }
        }

        public bool AddContact(Contacts contact)
        {
            if(contact != null)
            {
                contactsList.Add(contact);
                return true;
            }
            else
            {
                throw new ArgumentNullException("error adding contact");
            }
        }

        public bool RemoveContact(Contacts contact)
        {
            if (contact != null)
            {
                contactsList.Remove(contact);
                return true;
            }
            else
            {
                throw new ArgumentNullException("error removing contact");
            }
        }
    }
}
