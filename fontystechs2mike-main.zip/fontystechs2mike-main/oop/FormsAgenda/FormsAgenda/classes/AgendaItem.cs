﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public abstract class AgendaItem
    {
        public string Title { get; private set; }

        public AgendaItem(string title)
        {
            if(title == null)
            {
                throw new ArgumentNullException("error adding agendaitem");
            }
            Title = title;
        }
    }
}
