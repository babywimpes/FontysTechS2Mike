﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public  class Location
    {
        private string Adress { get; set; } 
        private string Room { get; set;} 
        public Location(string adress, string room)
        {
            if (adress == null || room == null)
            {
                throw new ArgumentNullException();
            }
            Adress = adress;
            Room = room;
        }
    }
}
