﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public class Appointment : AgendaItem
    {
        private DateTime AppointmentDate { get; set; }
        private Location loc { get; set; }
        private Contacts ContactsThere { get; set; }

        public Appointment(string title, DateTime appdate, Location loca, Contacts cont ) : base( title)
        {
            if (title == null || loca == null )
            {
                throw new ArgumentNullException();
            }
            AppointmentDate = appdate;
            loc = loca;
            if (cont != null)
            {
                ContactsThere = cont;
            }
            
        }   
    }
}
