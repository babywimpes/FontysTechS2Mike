﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public class Note : AgendaItem
    {
        public string Text { get; set; }
        
        public Note(string title, string text) : base(title) 
        {
            if (title == null || text == null)
            {
                throw new ArgumentNullException();
            }
            Text = text;
        }
    }
}
