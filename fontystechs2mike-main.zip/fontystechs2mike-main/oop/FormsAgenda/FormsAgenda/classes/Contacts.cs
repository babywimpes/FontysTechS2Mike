﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public class Contacts
    {
        private string Name { get; set; }
        private string PhoneNumber { get; set; }
        
        private Location Loca { get; set; }

        public Contacts(string name, string phoneNumber, Location loc)
        {
            if (name == null || phoneNumber == null)
            {
                throw new ArgumentNullException();
            }
            Name = name;
            PhoneNumber = phoneNumber;
            if (loc != null)
            {
                Loca = loc;
            }
            
        }
    }
}
