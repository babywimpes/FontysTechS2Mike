﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAgenda.Classes
{
    public class Reminder : AgendaItem
    {
        private DateTime reminderDate { get; set; }
        private string additionalInfo { get; set; }
        private bool Repeat { get; set; }
        private bool Done { get; set; }
        public Reminder(string title, DateTime remdate, string addinfo, bool rep, bool done) : base(title)
        {
            if( title == null)
            {
                throw new ArgumentNullException();
            }
            reminderDate = remdate;
            Repeat = rep;
            Done = done;

            if (addinfo != null)
            {
                additionalInfo = addinfo;
            }
        }
    }
}
