# Feedback

MusicPlayer 16 maart 2022
- maak setters public alleen als nodig, vaak zullen ze private zijn
- gebruik automatic properties als het kan, dat maakt de code veel compacter
- init alles in in de ctor, doe dus in de ctor de new van de lijsten. Maar init ook lyrics in die ctor, met null. 
  Lyrics is trouwens de enigste property die een public setter heeft, anders had e lyrics net zo goed weg kunnen laten.
- volg het klassediagram letterlijk, dust niet Song::_artist maar Song::Performer. En die moet public zijn.
  Songs ipv listSongs
  ....
- stop geen null objecten in je lijsten, is niet handig want als je iets met de lijst inhoud wilt doen moet je steeds cheken op null.
  Dus bijvoorbeeld:
    public void Add(Song song)
    {       if (song == null) return;
            Songs.Add(song);
    }
- zet overal private/public voor.
  Bijvoorbeeld:
  public  List<Song> Songs {get; private set}

AnimalShelter 30 maart 2022
- wil je dat de buitenwereld de prijs zelf kan invullen? Ik denk van niet, dus ISellable::Price heeft geen setter.
- animall::price moet abstract zijn, immers Animal kan de price niet bepalen, maar de Cat en Dog wel! Die 2 klassen overriden de Price getter.
- Cat::ToString() is niet correct geimplementeerd, kijk naar het groene commentaar!!  idem voor Dog.  Als je implementatie correct maakt, maak dan gebruik van de base::ToString
- Ik zie geen enkele testcase.


4 april 2022 AnimalShelter
- Ik zie toch enkele testcases, maar is vrijwel niets. En wat er is ziet er niet ok uit.
  Maak eerst overzicht (zijn eigenlijk de testcase namen) van wat je moet gaan testen, en daaarna pas implementeren. Voorbeeld van zo'n mogelijk overzicht:
   CatPriceTest_WhenBadHabitsHaslength40_ThenPriceIs20
   CatPriceTest_WhenBadHabitsHaslength41_ThenPriceIs20
   CatPriceTest_WhenBadHabitsHaslength39_ThenPriceIs21
   CatPriceTest_WhenBadHabitsIsNull_ThenPriceIs60
   CatToStringTest_WhenBadHabitsIsNull_ThenUnknownIsContainedInTheReturnedString
   CatToStringTest_WhenBadHabitsIsBadNull_ThenTheBadHabitsIsContainedInTheReturnedString
   ......