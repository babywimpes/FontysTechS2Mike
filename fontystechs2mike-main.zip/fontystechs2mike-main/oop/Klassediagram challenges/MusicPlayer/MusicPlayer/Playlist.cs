﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;

namespace MusicPlayer
{
    internal class Playlist
    {
        private string _name;
        public string Name { get; set; }

        public List<Song> Songs = new List<Song>();

        public Playlist(string sName)
        {
            Name = sName;
        }


        public void Add(Song song)
        {
            Songs.Add(song);
        }

        public void Add(List<Song> songs)
        {
            foreach(Song s in songs)
            {
                Songs.Add(s);
            }
        }

        public void Remove(Song song)
        {
            Songs.Remove(song);
        }

        public override string ToString()
        {
            string output = string.Join(",", Songs);
            return output;
        }
    }
}
