﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    internal class Song
    {
        private int _year;
        private string _name;
        private string _pathToFile;
        private string _lyrics;

        private Artist _artist;


        public int Year { get { return _year; } set { _year = value; } }
        public string Name { get { return _name; } set { _name = value; } }

        public string PathToFile { get { return _pathToFile; } set { _pathToFile = value; } }
        private string Lyrics { get { return _lyrics; } set { _lyrics = value; } }


        public Song(string name, int year, string pathtofile, Artist artist)
        {
            Name = name;
            Year = year;
            PathToFile = pathtofile;
            _artist = artist;
        }
        public override string ToString()
        {
            string output = $"Name: {Name}, Year:{Year}, Pathtofile:{PathToFile}";
            return output;
        }
    }
}
