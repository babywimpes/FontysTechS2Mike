﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    internal class MusicPlayers
    {

        List<Song> listSongs = new List<Song>();
        List<Playlist> listPlaylist = new List<Playlist>();
        List<Artist> listArtists = new List<Artist>();

        private Song _currentsong;
        public Song Currentsong { get { return _currentsong; } set { _currentsong = value; } }

        public MusicPlayers()
        {
            
        }


        public void Add(Artist artist)
        {
            listArtists.Add(artist);
        }
        public void Add(Playlist playlist)
        {
            listPlaylist.Add(playlist);
        }
        public void Add(Song song)
        {
            listSongs.Add(song);
        }
        public void Remove(Playlist playlist)
        {
            listPlaylist.Remove(playlist);
        }
        public void Play(Song song)
        {

        }
        public void Play(Playlist playlist)
        {

        }
        public Song IsPlaying()
        {
            return Currentsong;
        }

        public void StopPlaying()
        {
            Currentsong = null;
        }
    }
}
