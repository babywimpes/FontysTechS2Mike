﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MusicPlayer;

namespace MusicPlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        MusicPlayers player = new MusicPlayers();
        private void btnAddSong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = tbSongName.Text.ToString();
                int year = int.Parse(tbYear.Text);
                string path = tbPath.Text.ToString();
                string lyrics = tbLyrics.Text.ToString();

                Artist artist = lvArtist.SelectedItem as Artist;
                if(artist != null)
                {
                    Song song = new Song(name, year, path, artist);
                    lvSong.Items.Add(song);
                    player.Add(song);
                }

                else
                {
                    MessageBox.Show("Select an artist");
                }
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Something went wrong");
            }
        }

        private void btnAddArtist_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = tbSongName.Text.ToString();
                DateTime date = dpYear.SelectedDate.Value;
                Artist artist = new Artist(name, date);
                lvArtist.Items.Add(artist);
                player.Add(artist);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Something went wrong");
            }
        }
        private void btnAddPlaylist_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = tbplaylistname.Text.ToString();

                Playlist playlist = new Playlist(name);

                lvPlaylist.Items.Add(playlist);
                player.Add(playlist);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Something went wrong");
            }
        } 

        private void btnAddSongPlaylist_Click(object sender, RoutedEventArgs e)
        {

            Playlist playlist = lvPlaylist.SelectedItem as Playlist;
            Song song = lvSong.SelectedItem as Song;
            playlist.Add(song);
        }

        private void btnremoveSongPlaylist_Click(object sender, RoutedEventArgs e)
        {
            Playlist playlist = lvPlaylist.SelectedItem as Playlist;
            Song song = lvSong.SelectedItem as Song;
            playlist.Remove(song);
        }

        private void lvPlaylist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lvSelected.Items.Clear();
            
            var selectedItem = lvPlaylist.SelectedItem as Playlist;
            foreach(Song song in selectedItem.Songs)
            {
                lvSelected.Items.Add(song);
            }
        }

        private void btnPlayPlaylist_Click(object sender, RoutedEventArgs e)
        {
            tbCurrently.Text = lvPlaylist.SelectedItem.ToString();
        }

        private void btnPlaySong_Click(object sender, RoutedEventArgs e)
        {
            tbCurrently.Text = lvSelected.SelectedItem.ToString();
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            tbCurrently.Text = "None";
        }
    }
}
