﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    internal class Artist
    {
        private string _name;
        private DateTime _birthday;

        public string Name { get { return _name; } set { _name = value; } }

        public DateTime Birthday{ get { return _birthday; } set { _birthday = value; } }

        private List<Song> _songs = new List<Song>();

        public Artist(string name, DateTime date)
        {
            Name = name;
            Birthday = date;
        }

        public void Add(Song song)
        {
            _songs.Add(song);
        }
        public override string ToString()
        {
            string output = $"Name: {Name}, Birthday {Birthday}";
            return output;
        }

    }
}