﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace RondoNetworkTaxi
{
    class Program
    {
        const char CLIENTID = '4';
        static void Main(string[] args)
        {
            Console.Write("Enter IP: ");

            IPAddress ipc = IPAddress.Parse(Console.ReadLine());
            int port = 3456;

            Socket recv_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            recv_socket.Bind(new IPEndPoint(IPAddress.Any, port));
            recv_socket.Listen(5);

            Socket client = recv_socket.Accept();
            Console.WriteLine("Accepted client");

            Socket send_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            send_socket.Connect(new IPEndPoint(ipc, port));

            while (true)
            {
                byte[] buffer = new byte[1024];
                client.Receive(buffer);

                string message = Encoding.ASCII.GetString(buffer);
                if (message.StartsWith(CLIENTID))
                {

                    Console.WriteLine(Encoding.ASCII.GetString(buffer));
                }
                else
                {

                    send_socket.Send(buffer);
                }
            }
        }
    }
}
