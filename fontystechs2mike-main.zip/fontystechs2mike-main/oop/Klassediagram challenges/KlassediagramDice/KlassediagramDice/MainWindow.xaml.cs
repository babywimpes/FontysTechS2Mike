﻿using KlassediagramDice.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KlassediagramDice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Dice dice;
        List<Dice> diceLis;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCreateDice_Click(object sender, RoutedEventArgs e)
        {
            try{              
                if(string.IsNullOrEmpty(tbCustomDice.Text))
                {
                    dice = new Dice();   
                    diceLis.Add(dice);
                }
                else
                {
                    int numberofSides = int.Parse(tbCustomDice.Text);
                    if(numberofSides < 3)
                    {
                        MessageBox.Show("Ammount of sides must be 3 or more");                       
                    }
                    else 
                    {
                        dice = new Dice(numberofSides);
                        diceLis.Add(dice);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Please insert number");
            }
        }
    }
}
