﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlassediagramDice.Classes
{
    internal class Dice
    {

        private int _sides;

        public int Sides { get { return _sides; } set { _sides = value; } }
        //dice

        public Dice()
        {
            Sides = 6;
        }
        public Dice(int sides)
        {
            if(sides < 3)
            {
                sides = 3;
            }

            Sides= sides;
        }

        public int Throw()
        {
            Random random = new Random();
            return random.Next(1,Sides);
        }
        
        public int NrOfTimesThrown(int refSides, List<int>numberlist)
        {
            int refCount = 0;
            foreach(int number in numberlist)
            {
                if(number == refSides) { refCount++; }
            }
            return refCount;
        }

        public void ResetStatistics()
        {

        }

    }
}
