﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KlassediagramDice.Classes
{
    internal class Calculator
    {

        private double _result;

        public double Result { get { return _result; } set { _result = value; } }

        public Calculator()
        {

        }

        public double Add(double value)
        {
            return (Result + value);
        }
        public double Subtract(double value)
        {
            return (Result - value);
        }
        public double Multiply(double value)
        {
            return (Result * value);
        }
        public double Divide(double value)
        {
            return (Result / value);
        }

        public void Clear()
        {
            Result = 0;
        }
    }
}
