﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AnimalFileImporter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string fullfile = textBox1.Text + ".txt";

            try
            {
                StreamReader sr = new StreamReader(Path.Combine(docPath, fullfile));
                {
                    while (sr.Peek() >= 0)
                    {
                        listBox1.Items.Add(sr.ReadLine());
                    }
                }
            }
            catch (IOException _e)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(_e.Message);
            }
        }
    }
}
