﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfNotes.Classes;

namespace WpfNotes
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        
        string AddWhat;
        Administrator admin = new Administrator();
        public AddWindow(string addwhat )
        {
            InitializeComponent();
            AddWhat = addwhat;
            if(AddWhat == "note")
            {
                spReminder.Visibility = Visibility.Hidden; 
                spNote.Visibility = Visibility.Visible;
                Title = "Add Note";
            }
            else if(AddWhat == "reminder")
            {
                Title = "Add Reminder";
                spReminder.Visibility = Visibility.Visible;
                spNote.Visibility = Visibility.Hidden;
            }
            else
            {
                throw new ArgumentNullException("er is iets fout gegaan");
            }
        }

        private void btnAddClick(object sender, RoutedEventArgs e)
        {
            
            if (AddWhat == "note")
            {
                DateTime dateCreated = DateTime.Now;
                string notetitle = tbNoteTitle.Text;
                string notetext = tbNoteContent.Text;

                Note note = new Note(notetitle, notetext, dateCreated);
                admin.Add(note);
                
            }
            else if (AddWhat == "reminder")
            {
               
                DateTime dt = (DateTime)datePicker.SelectedDate;
                DateTime dateCreated = DateTime.Now;
                string remTitle = tbReminderTitle.Text;
                string remAddition;
                if(String.IsNullOrWhiteSpace(tbReminderAddition.Text)){
                    remAddition = "";
                }
                else { remAddition = tbReminderAddition.Text; }

                Reminder rem = new Reminder(remTitle, remAddition, dt, dateCreated);
                admin.Add(rem);
               
            }
            this.Close();
        }
    }
}
