﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfNotes.Classes
{
    public abstract class AgendaItem
    {
        public DateTime DateCreated { get; private set; }
        public string Title { get; set; }


        public AgendaItem(string title, DateTime date)
        {
            this.Title = title;
            this.DateCreated = date;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
