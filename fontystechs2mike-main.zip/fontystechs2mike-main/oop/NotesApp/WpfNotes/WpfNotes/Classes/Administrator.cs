﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfNotes.Classes
{
    class Administrator
    {
        MainWindow main;
        public List<Note> ListNotes;
        public List<Reminder> ListReminder;

        public Administrator()
        {
            main = new MainWindow();
            ListNotes = new List<Note>();
            ListReminder = new List<Reminder>();
           
        }

        public void LoadLists()
        {
            
            foreach (Note no in ListNotes)
            {
               // MessageBox.Show(no.ToString());
                main.spNotes.Children.Add(new Button
                {
                    Content = no.ToString(),
                    Width = 100,
                    Height = 100,
                    Background = new SolidColorBrush(Colors.Black),
                }); 

            }
            MessageBox.Show(ListNotes.Count.ToString());
            
            foreach(Reminder r in ListReminder)
            {
                
                //MessageBox.Show(r.ToString());
                main.spNotes.Children.Add(new TextBlock
                {
                    Text = r.ToString(),
                    Width = r.Title.Length,
                    Height = r.Title.Length,
                    Background = new SolidColorBrush(Colors.Black)
                });
            }
            
            
        }
        public void Add(Note n)
        {
            MessageBox.Show(ListNotes.Count.ToString());
            ListNotes.Add(n);
            MessageBox.Show(ListNotes.Count.ToString());
           // LoadLists();
        }
        public void Add(Reminder r)
        {
            ListReminder.Add(r);
            //LoadLists();
        }
    }
}
