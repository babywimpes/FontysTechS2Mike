﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfNotes.Classes
{
    class Reminder : AgendaItem
    {
        private DateTime ReminderTime;
        private string Addition;

        public Reminder(string Title, string addition, DateTime reminderdate, DateTime datecreated):base(Title, datecreated)
        {
            this.ReminderTime = reminderdate;
            this.Addition = addition;
        }

        public override string ToString()
        {
            string info = Title + " " + Addition + " " + ReminderTime + " " + DateCreated;

            return info;
        }

    }
}
