﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfNotes.Classes
{
    class Note : AgendaItem
    {
        private string Text;
        public Note(string title, string text, DateTime DateCreated) :base(title, DateCreated)
        {
            this.Text = text;
        }

        public override string ToString()
        {
            string info = Title + " " + Text + " " + DateCreated;

            return info;
        }
    }
}
