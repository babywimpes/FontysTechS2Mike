﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;

namespace AnimalShelter
{
    public class Administration
    {

        public List<Animal> Animals;

        
        public Administration()
        {
            Animals = new List<Animal>();
        }
        public bool Add(Animal animal)
        {
            if (animal != null)
            {
                if (FindAnimal(animal.ChipRegistrationNumber) == null)
                {
                    Animals.Add(animal);
                    return true;
                }               
            }
            else
            {
                throw new ArgumentNullException("animal");
            }

            return false;
        }
        public bool Remove(Animal animal)
        {
            if(animal == null)
            {
                throw new ArgumentNullException("animal");
            }
            return Animals.Remove(FindAnimal(animal.ChipRegistrationNumber));
        }

        public Animal FindAnimal(int chipnr)
        {
            if(chipnr < 0) throw new ArgumentOutOfRangeException("chipnr");

          
            for (int i = 0; i < Animals.Count; i++)
            {
                if (chipnr == Animals[i].ChipRegistrationNumber)
                {
                    return Animals[i];
                }
            }
            return null;
        }
         
        /// <summary>
        /// Saves all animals to a file with the given file name using serialisation.
        /// </summary>
        /// <param name="fileName">The file to write to.</param>
        public void Save(string fileName)
        {
            using (FileStream fs = new FileStream(fileName + ".dat", FileMode.Create))
            {

                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, Animals);
                
            }
         /*   string fullfile = fileName + ".dat";
            FileStream fs = new FileStream(fullfile, FileMode.Create);

            BinaryFormatter formatter = new BinaryFormatter();  // kijk eens naar using
            try
            {
                formatter.Serialize(fs, Animals);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to serialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }*/
        }

        /// <summary>
        /// Loads all animals from a file with the given file name using deserialisation.
        /// All animals currently in the administration are removed.
        /// </summary>
        /// <param name="fileName">The file to read from.</param>
        public void Load(string fileName)
        {
            string fullfile = fileName + ".dat";
            FileStream fs = new FileStream(fullfile, FileMode.Open);
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();

                // Deserialize the hashtable from the file and
                // assign the reference to the local variable.
                Animals = (List<Animal>)formatter.Deserialize(fs);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                
                fs.Close();
            }
            
        }

        /// <summary>
        /// Exports the info of all animals to a text file with the given file name.
        /// 
        /// Each line of the file contains the info about exactly one animal.
        /// Each line starts with the type of animal and a colon (e.g. 'Cat:' or 'Dog:')
        /// followed by the properties of the animal seperated by comma's.
        /// </summary>
        /// <param name="fileName">The text file to write to.</param>
        public void Export(string fileName)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string fullfile = fileName + ".txt";
            StreamWriter fs = new StreamWriter(Path.Combine(docPath, fullfile), true);
            try
            {   
                
                foreach(Animal a in Animals)
                {
                   
                    fs.WriteLine(a.ToString());
                }
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                throw;
            }
            finally
            {

                fs.Close();
            }
        }

    }
}
