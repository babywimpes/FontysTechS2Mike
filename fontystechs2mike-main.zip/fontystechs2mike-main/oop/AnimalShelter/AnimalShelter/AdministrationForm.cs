﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
namespace AnimalShelter
{
    public partial class AdministrationForm : Form
    {
        /// <summary>
        /// The (only) animal in this administration (for now....)
        /// </summary>
        private Administration admin = new Administration();

        /// <summary>
        /// Creates the form for doing adminstrative tasks
        /// </summary>
        public AdministrationForm()
        {
            InitializeComponent();

            SimpleDate date = new SimpleDate(1, 1, 2001);
            Dog dog = new Dog(1, date, "beest", date);
            Cat cat = new Cat(2, date, "katbeest", "ja");
            admin.Add(dog);
            admin.Add(cat);
            updateList();
        }

        /// <summary>
        /// Create an Animal object and store it in the administration.
        /// If "Dog" is selected in the animalTypeCombobox then a Dog object should be created.
        /// If "Cat" is selected in the animalTypeCombobox then a Cat object should be created.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void createAnimalButton_Click(object sender, EventArgs e)
        {
            string selected_object = animalTypeComboBox.SelectedItem.ToString();

            try
            {
                string name = textBox1.Text;
                int chipnr = Convert.ToInt32(numericUpDown1.Value);
                int dateday = Convert.ToInt32(numericUpDown2.Value);
                int datemonth = Convert.ToInt32(numericUpDown3.Value);
                int dateyear = Convert.ToInt32(numericUpDown4.Value);

                SimpleDate birthdate = new SimpleDate(dateday, datemonth, dateyear);
                if (selected_object[0] == 'D')
                {
                    int datedaywalk = Convert.ToInt32(numericUpDown5.Value);
                    int datemonthwalk = Convert.ToInt32(numericUpDown6.Value);
                    int dateyearwalk = Convert.ToInt32(numericUpDown7.Value);

                    SimpleDate lastWalkdate = new SimpleDate(datedaywalk, datemonthwalk, dateyearwalk);
                    Dog dog = new Dog(chipnr,birthdate,name,lastWalkdate);
                    admin.Add(dog);
                    updateList();

                }
                else if (selected_object[0] == 'C')
                {
                    string badhabit = textBox2.Text;
                    Cat cat = new Cat(chipnr,birthdate,name,badhabit);
  
                    admin.Add(cat);
                    
                    updateList();

                }
            }
            catch (ArgumentNullException _e)
            {
                MessageBox.Show(_e.Message); 
            }
            catch (FormatException _e)
            {
                MessageBox.Show(_e.Message);
            } 

           
        }

        /// <summary>
        /// Show the info of the animal referenced by the 'animal' field. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void showInfoButton_Click(object sender, EventArgs e)
        {
            try
            {
                Animal temp = lvAnimals.SelectedItem as Animal;
                MessageBox.Show(temp.ToString());
            }
            
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateList()
        {
            try
            {
                admin.Animals.Sort();
                lvAnimals.Items.Clear();
                lvAnimalsReserved.Items.Clear();
                foreach (Animal a in admin.Animals)
                {
                    if (a.IsReserved)
                    {
                        lvAnimalsReserved.Items.Add(a);
                    }
                    else
                    {
                        lvAnimals.Items.Add(a);
                    }
                }
            }
            catch(InvalidOperationException _e)
            {
                MessageBox.Show(_e.Message);
            }
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            try
            {
                Animal a = lvAnimals.SelectedItem as Animal;
                if(a == null)
                {
                    throw new Exception("niks geselecteerd");
                }

                a.IsReserved = true;

                updateList();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUnreserve_Click(object sender, EventArgs e)
        {
            try
            {
                Animal a = lvAnimalsReserved.SelectedItem as Animal;
                if (a == null)
                {
                    throw new Exception("niks geselecteerd");
                }
                a.IsReserved = false;

                updateList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                Animal a = lvAnimals.SelectedItem as Animal;
                if (a == null)
                {
                    throw new NullReferenceException("niks geselecteerd");
                }

                admin.Remove(a);

                updateList();
            }
            catch (ArgumentNullException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string path = textBoxPath.Text;
            admin.Save(path);
            updateList();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string path = textBoxPath.Text;
            admin.Load(path);
            updateList();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            string path = textBoxPath.Text;
            admin.Export(path);
        }
    }
}
