﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsAgenda.Classes;

namespace FormsAgendaTest
{
    [TestClass]
    public class TestReminder
    {
        [TestMethod]
        public void TestReminderConstructor()
        {
            Administrator administrator = new Administrator();
            DateTime dt = new DateTime(2016, 1, 1);
            Reminder rem = new Reminder("test", dt,"test", false, false);

            Assert.IsTrue(administrator.AddAgendaItem(rem));
            Assert.AreEqual("test", rem.Title);
            Assert.IsTrue(administrator.agendaItems.Contains(rem));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestReminderConstructor_EmptyReminderDate()
        {
            Administrator administrator = new Administrator();
            DateTime dt = new DateTime(2016, 1, 1);
            Reminder rem = new Reminder(null, dt , "test", false, false);
        }

        [TestMethod]
        public void testReminderConstructor_EmptyAdditionalInfo()
        {
            Administrator administrator = new Administrator();
            DateTime dt = new DateTime(2016, 1, 1);
            Reminder rem = new Reminder("test", dt, null, false, false);

            Assert.IsTrue(administrator.AddAgendaItem(rem));
            Assert.AreEqual("test", rem.Title);
            Assert.IsTrue(administrator.agendaItems.Contains(rem));
        }


    }
}
