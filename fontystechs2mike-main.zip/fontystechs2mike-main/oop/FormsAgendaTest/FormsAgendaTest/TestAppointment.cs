﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsAgenda.Classes;

namespace FormsAgendaTest
{
    [TestClass]
    public class TestAppointment
    {
        [TestMethod]
        public void TestAppointmentConstructor()
        {
            Administrator administrator = new Administrator();
            DateTime dt = new DateTime(2016, 1, 1);
            Location loca = new Location("test", "test");
            Contacts contact = new Contacts("test", "test", loca);
            Appointment app = new Appointment("test", dt, loca, contact);

            Assert.IsTrue(administrator.AddAgendaItem(app));
            Assert.AreEqual("test", app.Title);
            Assert.IsTrue(administrator.agendaItems.Contains(app));
        }   

        [TestMethod]
        public void CreateNewAppointment_EmptyContacts()
        {
            DateTime dt = new DateTime(2016, 1, 1);
            Location loca = new Location("test", "test");
            Appointment app = new Appointment("test", dt, loca, null);
            Assert.AreEqual("test", app.Title);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNewAppointment_EmptyLocation()
        {
            DateTime dt = new DateTime(2016, 1, 1);
            Appointment app = new Appointment("test", dt, null, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateNewAppointment_EmptyTitle()
        {
            DateTime dt = new DateTime(2016, 1, 1);
            Location loca = new Location("test", "test");
            Appointment app = new Appointment(null, dt, loca, null);
        }
    }
}
