﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WinFormsAgenda.Classes;

namespace FormsAgendaTest
{
    [TestClass]
    public class TestAdministrator
    {
        
        [TestMethod]
        public void CreateAgendaItem_note()
        {
            Note n = new Note("test", "test");
            Administrator administrator = new Administrator();
            Assert.IsTrue(administrator.AddAgendaItem(n));

            Assert.IsTrue(administrator.agendaItems.Contains(n));
        }

        [TestMethod]
        public void CreateAgendaItem_Reminder()
        {
            DateTime dt = DateTime.Now;
            Reminder r = new Reminder("test", dt, "test", false, false);
            Note n = new Note("test", "test");
            Administrator administrator = new Administrator();
            
            Assert.IsTrue(administrator.AddAgendaItem(n));
            Assert.IsTrue(administrator.agendaItems.Contains(n));
        }

        [TestMethod]
        public void CreateAgendaItem_Appointment()
        {
            Location loc = new Location("test", "test");
            DateTime dt = DateTime.Now;
            Appointment app = new Appointment("test", dt, loc, null);
            Administrator administrator = new Administrator();
            
            Assert.IsTrue(administrator.AddAgendaItem(app));
            Assert.IsTrue(administrator.agendaItems.Contains(app));
        }


        [TestMethod]
        public void CreateMultipleAgendaItems()
        {

            Administrator administrator = new Administrator();
            Location loc = new Location("test", "test");
            DateTime dt = DateTime.Now;
            
            Appointment app = new Appointment("test", dt, loc, null);
            Reminder r = new Reminder("test", dt, "test", false, false);
            Note n = new Note("test", "test");

            Assert.IsTrue(administrator.AddAgendaItem(app));
            Assert.IsTrue(administrator.AddAgendaItem(n));
            Assert.IsTrue(administrator.AddAgendaItem(r));

            Assert.IsTrue(administrator.agendaItems.Contains(app));
            Assert.IsTrue(administrator.agendaItems.Contains(n));
            Assert.IsTrue(administrator.agendaItems.Contains(r));
            Assert.AreEqual(3, administrator.agendaItems.Count);
        }

        [TestMethod]
        public void CreateNewContactWithLocation()
        {
            Administrator administrator = new Administrator();
            Location loc = new Location("test", "test");

            Contacts cont = new Contacts("test", "test", loc);
            Assert.IsTrue(administrator.AddContact(cont));

            Assert.IsTrue(administrator.contactsList.Contains(cont));
        }

        [TestMethod]
        
        public void CreateNewContactWithoutLocation()
        {
            Administrator administrator = new Administrator();
            Contacts cont = new Contacts("test", "test", null);
            Assert.IsTrue(administrator.AddContact(cont));

            Assert.IsTrue(administrator.contactsList.Contains(cont));
        }

            
    }
}
