﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AnimalShelter;


using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AnimalShelterTest
{
    [TestClass]
    public class TestAdministration
    {
        [TestMethod]
        public void TestAdministration_AddAnimal_ThenListContainsCat()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
            administration.Add(cat);
            Assert.IsTrue(administration.Animals.Contains(cat));
        }

        [TestMethod]
        public void TestAdministration_AddAnimal_ThenListContainsDog()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Dog dog = new Dog(1, simpledate, "test", simpledate);
            administration.Add(dog);
            Assert.IsTrue(administration.Animals.Contains(dog));
        }

        [TestMethod]
        public void TestAdministration_AddAnimal_ThenListContainsCatDog()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
            Dog dog = new Dog(1, simpledate, "test", simpledate);
            Assert.IsTrue(administration.Add(cat));
            Assert.IsTrue(administration.Add(dog));
            Assert.IsTrue(administration.Animals.Contains(cat));
            Assert.IsTrue(administration.Animals.Contains(dog));
        }
        [TestMethod]

        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAdministration_AddAnimal_Null()
        {
           
            Administration administration = new Administration();
            administration.Add(null);
        }

        [TestMethod]
        public void TestAdministration_RemovePresentAnimal_ThenTrueIsReturnedAndListDoesNotContainAnimal()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
            administration.Add(cat);
            Assert.IsTrue(administration.Remove(cat));
            Assert.IsFalse(administration.Animals.Contains(cat));
        }

        [TestMethod]
        public void TestAdministration_RemoveNotPresentAnimal_ThenFalseIsReturned()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
           
            Assert.IsFalse(administration.Remove(cat));
            Assert.IsFalse(administration.Animals.Contains(cat));
        }



        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestAdministration_RemoveAnimal_Null()
        {
            Administration administration = new Administration();
 
            administration.Remove(null);
        }

        [TestMethod]
        public void TestAdministration_FindAnimal_ThenListContainsAnimal()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
            administration.Add(cat);
            Assert.IsTrue(administration.FindAnimal(cat.ChipRegistrationNumber).Equals(cat));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestAdministration_FindAnimal_NegativeChipNr()
        {
            Administration administration = new Administration();
            administration.FindAnimal(-1);
        }

        [TestMethod]
        public void TestAdministration_Save_ThenListContainsAnimal()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Administration administration = new Administration();
            Cat cat = new Cat(1, simpledate, "test", "slapen");
            administration.Add(cat);
            administration.Save("test");
            administration.Load("test");
            Assert.IsTrue(administration.Animals.Contains(cat));
        }

    }
}
