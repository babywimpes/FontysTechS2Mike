﻿using System;
using AnimalShelter;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AnimalShelterTest
{
    [TestClass]
    public class TestCat
    {
        [TestMethod]
        public void TestCatBadHabbitsAdd()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(1, simpledate, "test", "slapen");

            Assert.AreEqual(cat.BadHabits, "slapen");


        }


        

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestCat_WhenChipNrIsNegative_ThenArgumentOutOfrangeExceptionIsThrown()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(-1, simpledate, "test", "slapen");
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestCat_WhenChipNrIsNegative_ThenArgumentNullExceptionIsThrown()
        {
            Cat cat = new Cat(1, null, "test", "slapen");
        }


        [TestMethod]
        public void TestCat_BadHabitsIsNull_ThenPriceIs60()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(1, simpledate, "test", null);
            Assert.AreEqual(60, cat.Price);
        }
        [TestMethod]
        public void TestCat_BadHabitsIs40Long_ThenPriceIs20()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(1, simpledate, "test", "0123456789012345678901234567890123456789");
            Assert.AreEqual(20, cat.Price);
        }
        [TestMethod]
        public void TestCat_BadHabitsIs41Long_ThenPriceIs20()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(1, simpledate, "test", "01234567890123456789012345678901234567890");
            Assert.AreEqual(20, cat.Price);
        }
        [TestMethod]
        public void TestCat_BadHabitsIs39Long_ThenPriceIs21()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Cat cat = new Cat(1, simpledate, "test", "012345678901234567890123456789012345678");
            Assert.AreEqual(21, cat.Price);
        }
    }
}
