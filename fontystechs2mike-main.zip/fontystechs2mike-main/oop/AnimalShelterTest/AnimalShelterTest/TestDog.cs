﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AnimalShelter;

namespace AnimalShelterTest
{
    [TestClass]
    public class TestDog
    {
        [TestMethod]       
        public void TestDogNameAddNotEqual()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(1, simpledate, "test", simpledate);

            Assert.AreNotEqual(dog.Name, "test2");


        }

        [TestMethod]
        public void TestDogTostring()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(1, simpledate, "test", simpledate);
            string info = dog.ToString();

            Assert.AreEqual(info, "Dog: 1, 02-12-2021, test, not reserved, 02-12-2021");

            dog.IsReserved = true;
            info = dog.ToString();

            Assert.AreEqual(info, "Dog: 1, 02-12-2021, test, reserved, 02-12-2021");
        }

        [TestMethod]
        public void TestNoNullExceptionCreationDog_LastWalkDate()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(1, simpledate, "test", null);
            string info2 = dog.ToString();

            Assert.AreEqual(info2, "Dog: 1, 02-12-2021, test, not reserved, unknown");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullExceptionCreationDog_DateofBirth()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(1, null, "test", simpledate);
            string info = dog.ToString();

            Assert.AreEqual(info, "1, 02-12-2021, test, 02-12-2021, 200");
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TestNullExceptionCreationDog_Name()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(1, simpledate, null, simpledate);
            string info = dog.ToString();

            Assert.AreEqual(info, "1, 02-12-2021, test, 02-12-2021, 200");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestNullExceptionCreationDog_Id()
        {
            int day = 2;
            int month = 12;
            int year = 2021;
            SimpleDate simpledate = new SimpleDate(day, month, year);
            Dog dog = new Dog(-1, simpledate, "test", simpledate);
            string info = dog.ToString();

            Assert.AreEqual(info, "1, 02-12-2021, test, 02-12-2021, 200");
        }
        
        



    }
}
