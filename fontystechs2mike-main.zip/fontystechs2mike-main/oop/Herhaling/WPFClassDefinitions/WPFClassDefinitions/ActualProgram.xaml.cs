﻿using System.Collections.ObjectModel;
using System.Windows;

namespace WPFClassDefinitions
{
    /// <summary>
    /// Interaction logic for ActualProgram.xaml
    /// </summary>
    public partial class ActualProgram : Window
    {

        ObservableCollection<Course> courseCollection = new ObservableCollection<Course>();
        private ObservableCollection<Results> resultCollection = new ObservableCollection<Results>();
        private ObservableCollection<Student> studentCollection = new ObservableCollection<Student>();
        public ActualProgram(ObservableCollection<Course> courses, ObservableCollection<Results> results, ObservableCollection<Student> students)
        {
            InitializeComponent();
            courseCollection= courses;
            resultCollection = results;
            studentCollection = students;

        }
    }
}
