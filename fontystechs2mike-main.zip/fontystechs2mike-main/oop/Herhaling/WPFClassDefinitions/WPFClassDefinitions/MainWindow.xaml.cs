﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace WPFClassDefinitions
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Course> courseCollection = new ObservableCollection<Course>();
        private ObservableCollection<Results> resultCollection = new ObservableCollection<Results>();
        private ObservableCollection<Student> studentCollection = new ObservableCollection<Student>();

        private List<int> tenp = new List<int>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddCourse_Click(object sender, RoutedEventArgs e)
        { 
            courseCollection.Add(new Course(tbCourseName.Text.ToString(), tbCourseCode.Text.ToString(), int.Parse(tbSBU.Text)));

            lvCourses.Items.Add(new Course(tbCourseName.Text.ToString(), tbCourseCode.Text.ToString(), int.Parse(tbSBU.Text)));
        }

        private void btnAddResult_Click(object sender, RoutedEventArgs e)
        {
            resultCollection.Add(new Results(tbCourseName2.Text.ToString(), int.Parse(tbCourseResult.Text)));

            lvResults.Items.Add(new Results(tbCourseName2.Text.ToString(), int.Parse(tbCourseResult.Text)));
        }

        private void btnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            int x = 0;
            string y= tbResults.Text;           
            string[] resultList = y.Split(", ");
            foreach (string result in resultList)
            {
                tenp.Add(int.Parse(result)) ;
            }
            
            studentCollection.Add(new Student(tbStudentDOB.Text.ToString(), tenp, tbStudentAdress.Text.ToString(), tbStudentName.Text.ToString(), int.Parse(tbStudentNumber.Text)));

            lvStudents.Items.Add(new Student(tbStudentDOB.Text.ToString(), tenp, tbStudentAdress.Text.ToString(), tbStudentName.Text.ToString(), int.Parse(tbStudentNumber.Text)));
        }
    }
}
